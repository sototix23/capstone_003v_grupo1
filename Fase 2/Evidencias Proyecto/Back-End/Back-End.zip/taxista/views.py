from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Conductor, Vehiculo, AsignacionVehiculoConductor, DireccionConductor
from .serializers import (
    ConductorSerializer,
    VehiculoSerializer,
    AsignacionVehiculoConductorSerializer,
)
from rest_framework import status
from viajes.models import Viaje  # Asegúrate de que esté importado el modelo
from .serializers import ViajeProgramadoSerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi


# Vista para el modelo Conductor
class ConductorViewSet(viewsets.ModelViewSet):
    queryset = Conductor.objects.all()
    serializer_class = ConductorSerializer
    lookup_field = (
        "rut_conductor"  # Usamos el rut en lugar del id para buscar conductores
    )

    @action(detail=True, methods=["get"])
    def asignaciones(self, request, rut_conductor=None):
        """
        Endpoint personalizado para obtener las asignaciones de un conductor.
        """
        try:
            conductor = (
                self.get_object()
            )  # Obtiene el conductor basado en rut_conductor
            hoy = date.today()

            # Filtrar asignaciones activas y optimizar la carga
            asignaciones = (
                AsignacionVehiculoConductor.objects.filter(
                    conductor=conductor,
                    fecha_asignacion__lte=hoy,
                    fecha_fin__gte=hoy,
                )
                .select_related("vehiculo", "conductor")
                .distinct()
            )

            if not asignaciones.exists():
                return Response(
                    {"detail": "No se encontraron asignaciones para este conductor."},
                    status=status.HTTP_404_NOT_FOUND,
                )

            serializer = AsignacionVehiculoConductorSerializer(asignaciones, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Conductor.DoesNotExist:
            return Response(
                {"detail": "Conductor no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=True, methods=["get"], url_path="viajes-programados")
    def viajes_programados(self, request, rut_conductor=None):
        """
        Endpoint para obtener los viajes programados de un conductor específico, incluyendo detalles y colaboradores.
        """
        try:
            conductor = self.get_object()
            viajes_asignados = Viaje.objects.filter(id_conductor=conductor)

            if not viajes_asignados.exists():
                return Response(
                    {
                        "detail": "No se encontraron viajes programados para este conductor."
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Serializar los viajes asignados con el serializer actualizado
            serializer = ViajeProgramadoSerializer(viajes_asignados, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Conductor.DoesNotExist:
            return Response(
                {"detail": "Conductor no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                "region",
                openapi.IN_QUERY,
                description="Filtra los conductores por el nombre de la región (por ejemplo, 'Región de Valparaíso')",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "comuna",
                openapi.IN_QUERY,
                description="Filtra los conductores por el nombre de la comuna (por ejemplo, 'Viña del Mar')",
                type=openapi.TYPE_STRING,
            ),
        ]
    )
    def list(self, request, *args, **kwargs):
        """
        Endpoint para obtener la lista de conductores con la opción de filtrar por región y comuna.
        """
        return super().list(request, *args, **kwargs)

    def filter_queryset(self, queryset):
        """
        Aplica filtros de región y comuna si están presentes en los parámetros de consulta.
        """
        region = self.request.query_params.get("region")
        comuna = self.request.query_params.get("comuna")

        if region or comuna:
            # Filtra direcciones según la región y comuna si están presentes
            direcciones = DireccionConductor.objects.all()
            if region:
                direcciones = direcciones.filter(region=region)
            if comuna:
                direcciones = direcciones.filter(comuna=comuna)

            # Filtrar los conductores por los rut_conductor asociados a las direcciones
            conductor_ruts = direcciones.values_list(
                "conductor__rut_conductor", flat=True
            ).distinct()
            queryset = queryset.filter(rut_conductor__in=conductor_ruts)

        return queryset


# Vista para el modelo Vehiculo
class VehiculoViewSet(viewsets.ModelViewSet):
    queryset = Vehiculo.objects.all()
    serializer_class = VehiculoSerializer
    lookup_field = "id"  # Se manejarán por ID, no rut

    @action(detail=True, methods=["get"])
    def conductores(self, request, id=None):
        """
        Endpoint personalizado para obtener los conductores asignados a un vehículo.
        """
        vehiculo = self.get_object()  # Obtiene el vehículo basado en lookup_field (id)
        asignaciones = AsignacionVehiculoConductor.objects.filter(vehiculo=vehiculo)
        conductores = [asignacion.conductor for asignacion in asignaciones]
        serializer = ConductorSerializer(conductores, many=True)
        return Response(serializer.data)


class AsignacionVehiculoConductorViewSet(viewsets.ModelViewSet):
    queryset = AsignacionVehiculoConductor.objects.all()
    serializer_class = AsignacionVehiculoConductorSerializer

    def create(self, request, *args, **kwargs):
        rut_conductor = request.data.get("rut_conductor")
        fecha_asignacion = request.data.get("fecha_asignacion")
        fecha_fin = request.data.get("fecha_fin")

        # Verificar si el conductor ya tiene una asignación en el rango de fechas
        asignaciones_existentes = AsignacionVehiculoConductor.objects.filter(
            conductor__rut_conductor=rut_conductor,
            fecha_asignacion__lte=fecha_fin,
            fecha_fin__gte=fecha_asignacion,
        )

        if asignaciones_existentes.exists():
            return Response(
                {
                    "detail": "El conductor ya tiene una asignación en este rango de fechas."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().create(request, *args, **kwargs)
