from rest_framework import serializers
from .models import Conductor, DireccionConductor, Vehiculo, AsignacionVehiculoConductor
from rest_framework import serializers
from viajes.models import Viaje, ViajeColaborador, RutaViaje
from colaboradores.models import Colaborador
from taxista.models import Vehiculo


# Serializador de Vehiculo
class VehiculoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vehiculo
        fields = [
            "id",
            "patente",
            "modelo",
            "marca",
            "color",
            "ano",
            "tipo_vehiculo",
            "capacidad_ocupantes",
            "numero_chasis",
            "numero_motor",
            "tipo_combustible",
            "url_foto",
        ]


# Agrega este serializador al principio
class DireccionConductorSerializer(serializers.ModelSerializer):
    class Meta:
        model = DireccionConductor
        fields = ["direccion", "comuna", "region", "es_principal"]


# Serializador de Conductor actualizado
class ConductorSerializer(serializers.ModelSerializer):
    direcciones = DireccionConductorSerializer(
        many=True, read_only=True
    )  # Usa el nuevo serializador aquí

    class Meta:
        model = Conductor
        fields = [
            "rut_conductor",
            "nombres",
            "apellido_paterno",
            "apellido_materno",
            "fecha_nacimiento",
            "telefono",
            "email",
            "licencia_conducir",
            "categoria_licencia",
            "fecha_vencimiento_licencia",
            "user_id",
            "url_foto",
            "direcciones",  # Incluye las direcciones correctamente usando DireccionConductorSerializer
        ]


# Serializador de AsignacionVehiculoConductor
class AsignacionVehiculoConductorSerializer(serializers.ModelSerializer):
    vehiculo = VehiculoSerializer(
        read_only=True
    )  # Relaciona con el serializador del vehículo
    id_vehiculo = serializers.PrimaryKeyRelatedField(
        queryset=Vehiculo.objects.all(), source="vehiculo"
    )  # Para poder asignar el id del vehículo al crear la asignación
    conductor = ConductorSerializer(
        read_only=True
    )  # Relaciona con el serializador del conductor
    rut_conductor = serializers.PrimaryKeyRelatedField(
        queryset=Conductor.objects.all(), source="conductor"
    )  # Para poder asignar el rut del conductor al crear la asignación

    class Meta:
        model = AsignacionVehiculoConductor
        fields = [
            "id",
            "vehiculo",
            "id_vehiculo",
            "conductor",
            "rut_conductor",  # Cambiado de id_conductor a rut_conductor
            "fecha_asignacion",
            "hora_asignacion",
            "fecha_fin",
            "hora_fin",
        ]


class ViajeProgramadoSerializer(serializers.ModelSerializer):
    vehiculo = serializers.SerializerMethodField()

    class Meta:
        model = Viaje
        fields = [
            "codigo_viaje",
            "fecha_salida",
            "hora_salida",
            "punto_partida",
            "punto_destino",
            "vehiculo",
        ]

    def get_vehiculo(self, obj):
        return {
            "patente": obj.id_vehiculo.patente if obj.id_vehiculo else None,
            "modelo": obj.id_vehiculo.modelo if obj.id_vehiculo else None,
            "marca": obj.id_vehiculo.marca if obj.id_vehiculo else None,
            "capacidad_ocupantes": (
                obj.id_vehiculo.capacidad_ocupantes if obj.id_vehiculo else None
            ),
        }


class ViajeProgramadoSerializer(serializers.ModelSerializer):
    vehiculo = serializers.SerializerMethodField()
    colaboradores = serializers.SerializerMethodField()
    ruta = serializers.SerializerMethodField()
    estado = serializers.SerializerMethodField()
    confirmado_por_conductor = serializers.BooleanField()

    class Meta:
        model = Viaje
        fields = [
            "id",  # ID del viaje
            "codigo_viaje",
            "fecha_salida",
            "hora_salida",
            "punto_partida",
            "punto_destino",
            "vehiculo",
            "numero_pasajeros",
            "kilometros",
            "valor_estimado",
            "observaciones",
            "tarifa_total",
            "estado_inicio_real",
            "estado_fin_real",
            "confirmado_por_conductor",  # Agregado
            "colaboradores",  # Lista de colaboradores en el viaje
            "ruta",  # Detalles de la ruta
            "estado",  # Estado del viaje con ID y nombre
        ]

    def get_vehiculo(self, obj):
        return {
            "patente": obj.id_vehiculo.patente if obj.id_vehiculo else None,
            "modelo": obj.id_vehiculo.modelo if obj.id_vehiculo else None,
            "marca": obj.id_vehiculo.marca if obj.id_vehiculo else None,
            "capacidad_ocupantes": (
                obj.id_vehiculo.capacidad_ocupantes if obj.id_vehiculo else None
            ),
        }

    def get_colaboradores(self, obj):
        # Obtener colaboradores asignados al viaje usando `rut_colaborador`
        colaboradores_viaje = ViajeColaborador.objects.filter(id_viaje=obj)
        colaboradores = []

        # Obtener todos los registros de RutaViaje para el viaje
        rutas_viaje = RutaViaje.objects.filter(id_viaje=obj)

        for c in colaboradores_viaje:
            colaborador = Colaborador.objects.filter(
                rut_colaborador=c.rut_colaborador
            ).first()
            if colaborador:
                # Obtener la dirección principal del colaborador
                direccion = colaborador.direcciones.filter(es_principal=True).first()

                # Encontrar la ruta correspondiente al `rut_colaborador`
                ruta_viaje = rutas_viaje.filter(
                    rut_colaborador=c.rut_colaborador
                ).first()

                colaboradores.append(
                    {
                        "rut_colaborador": colaborador.rut_colaborador,
                        "nombres": colaborador.nombres,
                        "apellido_paterno": colaborador.apellido_paterno,
                        "apellido_materno": colaborador.apellido_materno,
                        "direccion": direccion.direccion if direccion else None,
                        "comuna": direccion.comuna if direccion else None,
                        "region": direccion.region if direccion else None,
                        "hora_estimada_recogida": (
                            ruta_viaje.hora_estimada_recogida if ruta_viaje else None
                        ),
                        "hora_estimada_llegada": (
                            ruta_viaje.hora_estimada_llegada if ruta_viaje else None
                        ),  # Nuevo campo agregado
                        "latitud": ruta_viaje.latitud if ruta_viaje else None,
                        "longitud": ruta_viaje.longitud if ruta_viaje else None,
                        "qr_escaneado": c.qr_escaneado,
                        "orden": ruta_viaje.orden if ruta_viaje else None,
                    }
                )

        return colaboradores

    def get_ruta(self, obj):
        # Obtener detalles de la ruta (id, descripción y puntos cardinales)
        if obj.id_ruta:
            return {
                "id": obj.id_ruta.id,  # ID de la ruta
                "descripcion": obj.id_ruta.descripcion_ruta,
                "punto_inicial": {
                    "latitud": obj.id_ruta.punto_inicial_latitud,
                    "longitud": obj.id_ruta.punto_inicial_longitud,
                },
                "punto_final": {
                    "latitud": obj.id_ruta.punto_final_latitud,
                    "longitud": obj.id_ruta.punto_final_longitud,
                },
            }
        return None

    def get_estado(self, obj):
        # Obtener el id y nombre del estado del viaje
        return {
            "id": obj.id_estado.id if obj.id_estado else None,
            "nombre": obj.id_estado.nombre_estado if obj.id_estado else None,
        }
