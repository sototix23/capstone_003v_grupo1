import requests
import logging
from django.db import transaction
from django.conf import settings
from .models import Conductor, Vehiculo, AsignacionVehiculoConductor, DireccionConductor
from usuarios.models import User
from usuarios.views import (
    crear_usuario_taxista,
)  # Importa la función para crear el usuario

API_BASE_URL = "https://ryq-apis-1bf8cd7fef45.herokuapp.com/api"

# Configuración de logs
logger = logging.getLogger(__name__)


def obtener_token():
    """
    Solicita el token de autenticación a la API externa.
    """
    auth_url = f"{API_BASE_URL}/token/"
    auth_data = {
        "username": settings.API_USERNAME,
        "password": settings.API_PASSWORD,
    }
    try:
        response = requests.post(auth_url, data=auth_data)
        response.raise_for_status()
        logger.info("Token de autenticación obtenido con éxito.")
        return response.json().get("access")
    except requests.RequestException as e:
        logger.error(f"Error al obtener el token: {str(e)}")
        raise Exception("Error al obtener el token de autenticación")


@transaction.atomic
def sync_conductores():
    logger.info(
        "Iniciando sincronización de conductores, vehículos, asignaciones y direcciones..."
    )

    # Obtener token
    token = obtener_token()
    headers = {"Authorization": f"Bearer {token}"}

    try:
        # Sincronizar Conductores
        logger.info("Sincronizando conductores...")
        response_conductores = requests.get(
            f"{API_BASE_URL}/conductor/", headers=headers
        )
        response_conductores.raise_for_status()
        conductores_data = response_conductores.json()

        for conductor_data in conductores_data:
            # Crear o actualizar el conductor
            conductor, created = Conductor.objects.update_or_create(
                rut_conductor=conductor_data["rut_conductor"],
                defaults={
                    "nombres": conductor_data["nombres"],
                    "apellido_paterno": conductor_data["apellido_paterno"],
                    "apellido_materno": conductor_data["apellido_materno"],
                    "fecha_nacimiento": conductor_data["fecha_nacimiento"],
                    "telefono": conductor_data.get("telefono", ""),
                    "email": conductor_data.get("email", ""),
                    "licencia_conducir": conductor_data["licencia_conducir"],
                    "categoria_licencia": conductor_data.get("categoria_licencia", ""),
                    "fecha_vencimiento_licencia": conductor_data.get(
                        "fecha_vencimiento_licencia", None
                    ),
                },
            )

            # Crear el usuario correspondiente al conductor usando la función `crear_usuario_taxista`
            crear_usuario_taxista(conductor_data)

            # Asignar el id del usuario al conductor
            user = User.objects.filter(rut=conductor.rut_conductor).first()
            if user:
                conductor.user = user
                conductor.save()

            # Sincronizar Direcciones del Conductor
            logger.info(
                f"Sincronizando direcciones para el conductor {conductor.rut_conductor}..."
            )
            direccion_url = (
                f"{API_BASE_URL}/conductor/rut/{conductor.rut_conductor}/direccion/"
            )
            try:
                response_direcciones = requests.get(direccion_url, headers=headers)
                response_direcciones.raise_for_status()
                direcciones_data = response_direcciones.json()

                for direccion_data in direcciones_data:
                    DireccionConductor.objects.update_or_create(
                        conductor=conductor,
                        direccion=direccion_data["direccion"],
                        defaults={
                            "comuna": direccion_data["comuna"]["nombre"],
                            "region": direccion_data["comuna"]["region"]["nombre"],
                            "es_principal": direccion_data.get("es_principal", False),
                        },
                    )
            except requests.HTTPError as e:
                if e.response.status_code == 404:
                    logger.warning(
                        f"No se encontró el endpoint de direcciones para el conductor {conductor.rut_conductor}. URL: {direccion_url}"
                    )
                else:
                    logger.error(
                        f"Error al sincronizar direcciones para el conductor {conductor.rut_conductor}: {str(e)}"
                    )
                    raise

        logger.info(
            f"Sincronización completada para {len(conductores_data)} conductores y sus direcciones."
        )

        # Sincronizar Vehículos
        logger.info("Sincronizando vehículos...")
        response_vehiculos = requests.get(
            f"{API_BASE_URL}/conductor/vehiculo/", headers=headers
        )
        response_vehiculos.raise_for_status()
        vehiculos_data = response_vehiculos.json()

        for vehiculo_data in vehiculos_data:
            Vehiculo.objects.update_or_create(
                patente=vehiculo_data["patente"],
                defaults={
                    "marca": vehiculo_data["marca"]["nombre"],
                    "modelo": vehiculo_data["modelo"]["nombre"],
                    "color": vehiculo_data["color"]["nombre"],
                    "ano": vehiculo_data["ano"],
                    "tipo_vehiculo": vehiculo_data["tipo_vehiculo"]["tipo"],
                    "capacidad_ocupantes": vehiculo_data["tipo_vehiculo"][
                        "capacidad_ocupantes"
                    ],
                    "numero_chasis": vehiculo_data.get("numero_chasis", ""),
                    "numero_motor": vehiculo_data.get("numero_motor", ""),
                    "tipo_combustible": vehiculo_data.get("tipo_combustible", ""),
                },
            )
        logger.info(f"Sincronización completada para {len(vehiculos_data)} vehículos.")

        # Sincronizar Asignaciones de Vehículos
        logger.info("Sincronizando asignaciones de vehículos...")
        response_asignaciones = requests.get(
            f"{API_BASE_URL}/conductor/asignacion/", headers=headers
        )
        response_asignaciones.raise_for_status()
        asignaciones_data = response_asignaciones.json()

        # Pre-cargar vehículos y conductores para evitar múltiples consultas
        patentes = [
            asignacion["vehiculo"]["patente"] for asignacion in asignaciones_data
        ]
        ruts = [
            asignacion["conductor"]["rut_conductor"] for asignacion in asignaciones_data
        ]

        vehiculos = Vehiculo.objects.filter(patente__in=patentes).in_bulk(
            field_name="patente"
        )
        conductores = Conductor.objects.filter(rut_conductor__in=ruts).in_bulk(
            field_name="rut_conductor"
        )

        for asignacion_data in asignaciones_data:
            vehiculo = vehiculos.get(asignacion_data["vehiculo"]["patente"])
            conductor = conductores.get(asignacion_data["conductor"]["rut_conductor"])

            if vehiculo and conductor:
                # Eliminar posibles duplicados basados en `vehiculo`, `conductor` y `fecha_asignacion`
                AsignacionVehiculoConductor.objects.filter(
                    vehiculo=vehiculo,
                    conductor=conductor,
                    fecha_asignacion=asignacion_data["fecha_asignacion"],
                ).delete()

                # Crear o actualizar la asignación
                AsignacionVehiculoConductor.objects.update_or_create(
                    vehiculo=vehiculo,
                    conductor=conductor,
                    fecha_asignacion=asignacion_data[
                        "fecha_asignacion"
                    ],  # Añadido para distinguir asignaciones
                    defaults={
                        "hora_asignacion": asignacion_data.get("hora_asignacion", None),
                        "fecha_fin": asignacion_data["fecha_fin"],
                        "hora_fin": asignacion_data.get("hora_fin", None),
                    },
                )
        logger.info(
            f"Sincronización completada para {len(asignaciones_data)} asignaciones."
        )

    except requests.RequestException as e:
        logger.error(f"Error durante la sincronización: {str(e)}")
        raise Exception("Error durante la sincronización")
