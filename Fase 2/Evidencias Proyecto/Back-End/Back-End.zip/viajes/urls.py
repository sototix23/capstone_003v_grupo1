from rest_framework.routers import DefaultRouter
from .views import (
    EstadoViewSet,
    RutaViewSet,
    ViajeViewSet,
    RutaViajeViewSet,
    ViajeColaboradorViewSet,
    GenerarQRView,  # Importamos la nueva vista
    ValidarQRView,  # Importamos la nueva vista
    LogEscaneoQRViewSet,
    TipoViajeViewSet,
    IncidenciaViajeViewSet,  # Nueva vista de IncidenciaViaje
    LogIncidenciaViajeCreateView,  # Nueva vista de LogIncidenciaViaje
    ReporteAsistenciaViewSet,
    ReporteUsoTransporteViewSet,
    IncidenciaGeneralViewSet,
)

from django.urls import path

router = DefaultRouter()
router.register(r"estados", EstadoViewSet, basename="estados")
router.register(r"rutas", RutaViewSet, basename="rutas")
router.register(r"viajes", ViajeViewSet, basename="viajes")
router.register(r"rutas-viajes", RutaViajeViewSet, basename="rutas-viajes")
router.register(r"tipo-viaje", TipoViajeViewSet, basename="tipo-viaje")
router.register(
    r"viajes-colaboradores", ViajeColaboradorViewSet, basename="viajes-colaboradores"
)
router.register(r"logs-qr", LogEscaneoQRViewSet, basename="logs_qr")
router.register(
    r"incidencias-viaje", IncidenciaViajeViewSet, basename="incidencias-viaje"
)
router.register(
    r"reporte-asistencias", ReporteAsistenciaViewSet, basename="reporte-asistencias"
)
router.register(
    r"reporte-uso-transporte",
    ReporteUsoTransporteViewSet,
    basename="reporte-uso-transporte",
)

router.register(
    r"incidencias-generales", IncidenciaGeneralViewSet, basename="incidencias-generales"
)


urlpatterns = router.urls

# Agregamos las rutas manualmente para generar y validar QR, y crear logs de incidencias
urlpatterns += [
    path(
        "generar-qr/<int:id_viaje>/<str:rut_colaborador>/",
        GenerarQRView.as_view(),
        name="generar_qr",
    ),
    path("validar-qr/", ValidarQRView.as_view(), name="validar_qr"),
    path(
        "logs-incidencias-viaje/",
        LogIncidenciaViajeCreateView.as_view(),
        name="logs_incidencias_viaje",
    ),
]
