import hashlib
from django.forms import ValidationError
from rest_framework import permissions, viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import (
    Estado,
    Ruta,
    Viaje,
    RutaViaje,
    ViajeColaborador,
    Colaborador,
    LogEscaneoQR,
    Conductor,
    TipoViaje,
    CalificacionComentario,
)
from .serializers import (
    EstadoSerializer,
    RutaSerializer,
    ViajeSerializer,
    RutaViajeSerializer,
    ViajeColaboradorSerializer,
    LogEscaneoQRSerializer,
    ValidarQRSerializer,
    TipoViajeSerializer,
    CalificacionComentarioSerializer,
    AsistenciaReporteSerializer,
    ReporteUsoTransporteSerializer,
)
from rest_framework.permissions import IsAuthenticated
from colaboradores.models import Colaborador
from django.db.utils import IntegrityError
from datetime import datetime
from django.utils.timezone import make_aware
from rest_framework.views import APIView
from .utils import generar_codigo_qr
from taxista.models import Conductor
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from datetime import timedelta
from django.utils import timezone
from rest_framework.exceptions import PermissionDenied
import hashlib
import pytz
from taxista.serializers import (
    VehiculoSerializer,
)  # Cambia 'taxista' por el nombre correcto si es diferente

from .emails import (
    enviar_correo_cancelacion_viaje,
    enviar_correo_cancelacion_viaje_completo,
    enviar_correo_cancelacion_conductor,
    enviar_correo_viaje_ruta,
    enviar_correo_asignacion_conductor,
)
from rest_framework import generics
from .models import IncidenciaViaje, LogIncidenciaViaje
from .serializers import IncidenciaViajeSerializer, LogIncidenciaViajeSerializer
from rest_framework.pagination import PageNumberPagination
from django.db.models import Count, Q
from django.db.models.functions import TruncDay, TruncMonth, TruncYear
from campamentero.models import IncidenciaHabitacion
from campamentero.serializers import IncidenciaHabitacionSerializer
from datetime import datetime
from django.utils.timezone import now
from pytz import timezone as pytz_timezone


class LargeResultsSetPagination(PageNumberPagination):
    page_size = 10


# Permiso personalizado que permite solo a Administradores y Logística crear, actualizar y eliminar.
class IsAdminOrLogistica(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.user.groups.filter(name__in=["Administrador", "Logística"]).exists():
            return True
        if view.action in [
            "list",
            "retrieve",
        ]:  # Permitir a todos ver los viajes y rutas
            return True
        return False


class EstadoViewSet(viewsets.ModelViewSet):
    queryset = Estado.objects.all()
    serializer_class = EstadoSerializer
    permission_classes = [IsAuthenticated]


class RutaViewSet(viewsets.ModelViewSet):
    queryset = Ruta.objects.all()
    serializer_class = RutaSerializer
    permission_classes = [IsAuthenticated]


class TipoViajeViewSet(viewsets.ModelViewSet):
    queryset = TipoViaje.objects.all()
    serializer_class = TipoViajeSerializer
    permission_classes = [IsAuthenticated]


class ViajeViewSet(viewsets.ModelViewSet):
    queryset = Viaje.objects.all()
    serializer_class = ViajeSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = LargeResultsSetPagination  # Aplica la paginación aquí

    def get_queryset(self):
        # Fecha actual
        fecha_actual = now()

        # Calcular la fecha límite futura (4 semanas hacia adelante)
        fecha_limite_futura = fecha_actual + timedelta(weeks=4)

        # Calcular la fecha límite pasada (2 meses hacia atrás desde la fecha futura)
        fecha_limite_pasada = fecha_limite_futura - timedelta(days=60)

        # Filtrar viajes creados en el rango de fechas y ordenar por fecha de creación
        return Viaje.objects.filter(
            fecha_creacion__gte=fecha_limite_pasada,  # Desde hace 2 meses hacia atrás
            fecha_creacion__lte=fecha_limite_futura,  # Hasta 4 semanas hacia adelante
        ).order_by("-fecha_creacion")

    @action(detail=True, methods=["get"], permission_classes=[IsAuthenticated])
    def info_viaje(self, request, pk=None):
        """
        Muestra la información detallada de un viaje, incluyendo colaboradores, detalles de la ruta,
        puntos de la ruta asociados (RutaViaje) y detalles completos del vehículo.
        """
        try:
            # Obtener el viaje por su ID
            viaje = self.get_object()

            # Filtrar los colaboradores asociados al viaje
            colaboradores = ViajeColaborador.objects.filter(id_viaje=viaje)

            # Obtener la ruta y vehículo relacionados al viaje
            ruta = viaje.id_ruta
            vehiculo = viaje.id_vehiculo  # Obtener el vehículo

            ruta_data = (
                RutaSerializer(ruta).data if ruta else None
            )  # Serializar la ruta
            vehiculo_data = (
                VehiculoSerializer(vehiculo).data if vehiculo else None
            )  # Serializar el vehículo

            # Obtener los puntos de la ruta (RutaViaje) relacionados con el viaje
            puntos_ruta = RutaViaje.objects.filter(id_viaje=viaje)
            puntos_ruta_data = RutaViajeSerializer(puntos_ruta, many=True).data

            # Serializar colaboradores y viaje
            colaboradores_data = ViajeColaboradorSerializer(
                colaboradores, many=True
            ).data
            viaje_data = ViajeSerializer(viaje).data

            # Responder con todos los datos: viaje, colaboradores, ruta, puntos de la ruta, y vehículo
            return Response(
                {
                    "viaje": viaje_data,
                    "colaboradores": colaboradores_data,
                    "ruta": ruta_data,
                    "puntos_ruta": puntos_ruta_data,
                    "vehiculo": vehiculo_data,  # Incluir los detalles del vehículo
                },
                status=status.HTTP_200_OK,
            )

        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )

    def perform_create(self, serializer):
        """Guarda el usuario creador al crear un viaje."""
        serializer.save(usuario_creador=self.request.user)

    def perform_update(self, serializer):
        """Guarda el usuario modificador al actualizar un viaje."""
        serializer.save(usuario_modificador=self.request.user)

    def perform_update(self, serializer):
        """
        Detecta si se asigna un conductor al actualizar el viaje y envía un correo.
        """
        viaje = self.get_object()  # Obtener el viaje antes de actualizar
        previous_conductor = (
            viaje.id_conductor
        )  # Guardar el conductor actual antes del cambio
        serializer.save(usuario_modificador=self.request.user)  # Actualizar el viaje

        # Verificar si se asignó un nuevo conductor
        nuevo_conductor = serializer.instance.id_conductor
        if nuevo_conductor and nuevo_conductor != previous_conductor:
            # Enviar correo al nuevo conductor con los detalles del viaje
            try:
                enviar_correo_asignacion_conductor(nuevo_conductor, serializer.instance)
                print(f"Correo enviado al conductor: {nuevo_conductor.email}")
            except Exception as e:
                print(f"Error al enviar correo al conductor: {str(e)}")

    @action(
        detail=True, methods=["patch"], permission_classes=[permissions.IsAuthenticated]
    )
    def cancelar(self, request, pk=None):
        viaje = self.get_object()
        motivo = request.data.get("motivo_cancelacion")

        if not motivo:
            return Response(
                {"error": "Motivo de cancelación requerido."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        viaje.motivo_cancelacion = motivo

        try:
            estado_cancelado = Estado.objects.get(
                nombre_estado="Cancelado", entidad="Viaje"
            )
        except Estado.MultipleObjectsReturned:
            return Response(
                {
                    "error": "Existen múltiples estados con el nombre 'Cancelado' para la entidad 'Viaje'."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Estado.DoesNotExist:
            return Response(
                {"error": "Estado 'Cancelado' para la entidad 'Viaje' no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )

        viaje.id_estado = estado_cancelado
        viaje.save()

        colaboradores_asignados = ViajeColaborador.objects.filter(id_viaje=viaje)
        for asignacion in colaboradores_asignados:
            try:
                # Convertir `rut_colaborador` en un objeto Colaborador
                colaborador = Colaborador.objects.get(
                    rut_colaborador=asignacion.rut_colaborador
                )
                enviar_correo_cancelacion_viaje_completo(colaborador, viaje, motivo)
            except Colaborador.DoesNotExist:
                print(
                    f"Colaborador con RUT {asignacion.rut_colaborador} no encontrado."
                )
                continue

        if viaje.id_conductor:
            enviar_correo_cancelacion_conductor(viaje.id_conductor, viaje, motivo)

        return Response(
            {"status": "Viaje cancelado exitosamente y notificaciones enviadas."},
            status=status.HTTP_200_OK,
        )

    @action(detail=True, methods=["get"], url_path="calificaciones")
    def obtener_calificaciones(self, request, pk=None):
        """
        Recupera las calificaciones y comentarios de un viaje específico.
        """
        try:
            viaje = self.get_object()
            calificaciones = CalificacionComentario.objects.filter(viaje=viaje)

            if not calificaciones.exists():
                return Response(
                    {
                        "detail": "Aún no hay calificaciones ni comentarios para este viaje."
                    },
                    status=status.HTTP_200_OK,
                )

            # Serializar los comentarios y calificaciones si existen
            serializer = CalificacionComentarioSerializer(calificaciones, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )


class RutaViajeViewSet(viewsets.ModelViewSet):
    queryset = RutaViaje.objects.all()
    serializer_class = RutaViajeSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["post"], url_path="crear-multiples")
    def crear_multiples(self, request):
        """
        Permite crear múltiples puntos de RutaViaje en una sola solicitud.
        """
        print(
            "Datos recibidos en el POST:", request.data
        )  # Imprime los datos recibidos

        datos_rutas = request.data  # Espera recibir una lista de rutas
        errores = []
        rutas_creadas = []

        # Definir la zona horaria de Santiago
        santiago_tz = pytz_timezone(
            "America/Santiago"
        )  # Usa pytz_timezone en lugar de timezone
        ahora_santiago = datetime.now(santiago_tz)

        # Iterar sobre los datos recibidos y crear cada punto de RutaViaje
        for ruta_data in datos_rutas:
            print(
                "Datos de una ruta individual:", ruta_data
            )  # Imprime cada dato individual

            id_viaje = ruta_data.get("id_viaje")
            rut_colaborador = ruta_data.get("rut_colaborador")

            # Validar que el viaje exista
            viaje = Viaje.objects.filter(id=id_viaje).first()
            if not viaje:
                errores.append(f"No se encontró el viaje con ID {id_viaje}.")
                continue

            # Validar que el estado del viaje sea válido para agregar rutas
            if (
                viaje.id_estado.nombre_estado in ["En Curso", "Cancelado", "Completado"]
                and viaje.id_estado.entidad == "Viaje"
            ):
                errores.append(
                    f"No se pueden asignar rutas al viaje {viaje.codigo_viaje} porque está en estado '{viaje.id_estado.nombre_estado}'."
                )
                continue

            # Convertir fecha y hora de salida a la zona horaria de Santiago
            fecha_salida = viaje.fecha_salida
            hora_salida = viaje.hora_salida
            fecha_hora_salida = santiago_tz.localize(
                datetime.combine(fecha_salida, hora_salida)
            )

            print(f"Fecha y hora de salida del viaje en Santiago: {fecha_hora_salida}")
            print(f"Hora actual en Santiago: {ahora_santiago}")

            # Validar que la fecha de salida no sea pasada
            if fecha_hora_salida < ahora_santiago:
                errores.append(
                    f"El viaje con ID {id_viaje} ya tiene una fecha de salida pasada (según la hora de Santiago)."
                )
                continue

            # Validar que el colaborador no tenga una ruta asignada en el mismo viaje
            if RutaViaje.objects.filter(
                id_viaje=id_viaje, rut_colaborador=rut_colaborador
            ).exists():
                errores.append(
                    f"El colaborador con RUT {rut_colaborador} ya tiene una ruta asignada en el viaje con ID {id_viaje}."
                )
                continue

            # Crear la ruta
            serializer = self.get_serializer(data=ruta_data)
            if serializer.is_valid():
                ruta_viaje = serializer.save()  # Guardar y obtener la instancia creada
                rutas_creadas.append(serializer.data)

                # Enviar el correo con los detalles de la ruta
                try:
                    enviar_correo_viaje_ruta(ruta_viaje)
                    print(f"Datos del RutaViaje: {ruta_viaje.__dict__}")

                except Exception as e:
                    errores.append(
                        f"No se pudo enviar el correo para la ruta con ID {ruta_viaje.id}: {str(e)}"
                    )
            else:
                errores.append(serializer.errors)

        if errores:
            return Response(
                {
                    "status": "Algunos puntos de ruta no pudieron ser creados.",
                    "errores": errores,
                    "rutas_creadas": rutas_creadas,
                },
                status=status.HTTP_207_MULTI_STATUS,
            )

        return Response(
            {
                "status": "Todos los puntos de RutaViaje fueron creados correctamente.",
                "rutas_creadas": rutas_creadas,
            },
            status=status.HTTP_201_CREATED,
        )

    @action(
        detail=False,
        methods=["get"],
        url_path="buscar-por-rut/(?P<rut_colaborador>[^/.]+)",
    )
    def buscar_por_rut(self, request, rut_colaborador=None):
        rutas = RutaViaje.objects.filter(rut_colaborador=rut_colaborador)
        if not rutas.exists():
            return Response(
                {"detail": "No se encontraron rutas para el colaborador."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = self.get_serializer(rutas, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ViajeColaboradorViewSet(viewsets.ModelViewSet):
    queryset = ViajeColaborador.objects.all()
    serializer_class = ViajeColaboradorSerializer
    permission_classes = [permissions.IsAuthenticated]

    # Indicamos que el campo de búsqueda es 'rut_colaborador'
    lookup_field = "rut_colaborador"

    # Sobrescribir el método destroy para desactivar el borrado
    def destroy(self, request, *args, **kwargs):
        """
        Desactiva el método destroy - Eliminar un colaborador de todos los viajes está deshabilitado.
        """
        return Response(
            {
                "message": "La eliminación de un colaborador de todos los viajes está deshabilitada."
            },
            status=status.HTTP_403_FORBIDDEN,  # Código de estado 403 para denegar acceso a esta funcionalidad
        )

    def retrieve(self, request, rut_colaborador=None, *args, **kwargs):
        """GET - Recupera todos los registros de un colaborador por `rut_colaborador`."""
        viajes_colaborador = self.get_queryset().filter(rut_colaborador=rut_colaborador)

        if not viajes_colaborador.exists():
            return Response(
                {"detail": "No se encontraron viajes para este colaborador."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = self.get_serializer(viajes_colaborador, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["get"], url_path="viaje/(?P<id_viaje>[^/.]+)")
    def viaje(self, request, id_viaje=None):
        """
        GET - Devuelve los colaboradores asociados a un viaje específico.
        """
        colaboradores = self.get_queryset().filter(id_viaje=id_viaje)

        if not colaboradores.exists():
            return Response(
                {"detail": "No se encontraron colaboradores para este viaje."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = self.get_serializer(colaboradores, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(
        detail=False, methods=["get"], url_path="disponibilidad/(?P<id_viaje>[^/.]+)"
    )
    def disponibilidad(self, request, id_viaje=None):
        """
        GET - Devuelve los colaboradores disponibles y no disponibles para un viaje.
        """
        try:
            viaje = Viaje.objects.get(pk=id_viaje)

            # Obtener los colaboradores asignados al viaje
            colaboradores_asignados = ViajeColaborador.objects.filter(
                id_viaje=viaje
            ).values_list("rut_colaborador", flat=True)

            # Obtener todos los colaboradores
            todos_colaboradores = Colaborador.objects.all()

            # Función para obtener la comuna, región y turno del contrato más reciente
            def obtener_datos_colaborador(colaborador):
                # Obtener dirección principal
                direccion = colaborador.direcciones.filter(es_principal=True).first()
                comuna = direccion.comuna if direccion else None
                region = direccion.region if direccion else None

                # Obtener el contrato más reciente del colaborador para extraer el turno
                contrato = colaborador.contratos.order_by("-fecha_ingreso").first()
                turno = contrato.turno if contrato else "N/A"

                return {
                    "comuna": comuna,
                    "region": region,
                    "turno": turno,
                }

            # Separar los colaboradores disponibles y no disponibles
            disponibles = [
                {
                    "rut_colaborador": col.rut_colaborador,
                    "nombre": col.nombres,
                    "apellido_paterno": col.apellido_paterno,
                    "apellido_materno": col.apellido_materno,
                    **obtener_datos_colaborador(col),  # Agregar comuna, región y turno
                }
                for col in todos_colaboradores
                if col.rut_colaborador not in colaboradores_asignados
            ]

            no_disponibles = [
                {
                    "rut_colaborador": col.rut_colaborador,
                    "nombre": col.nombres,
                    "apellido_paterno": col.apellido_paterno,
                    "apellido_materno": col.apellido_materno,
                    **obtener_datos_colaborador(col),  # Agregar comuna, región y turno
                }
                for col in todos_colaboradores
                if col.rut_colaborador in colaboradores_asignados
            ]

            return Response(
                {
                    "viaje_id": id_viaje,
                    "disponibles": disponibles,
                    "no_disponibles": no_disponibles,
                },
                status=status.HTTP_200_OK,
            )

        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )

    @action(detail=False, methods=["post"], permission_classes=[IsAuthenticated])
    def asignar(self, request):
        colaboradores_data = request.data
        errores = []
        asignados = []

        for colaborador_data in colaboradores_data:
            rut_colaborador = colaborador_data.get("rut_colaborador")
            viaje_id = colaborador_data.get("id_viaje")
            estado_id = colaborador_data.get("id_estado")
            hora_asignacion = colaborador_data.get("hora_asignacion")

            if not all([rut_colaborador, viaje_id, estado_id, hora_asignacion]):
                errores.append(
                    f"Todos los campos son requeridos para el colaborador {rut_colaborador}."
                )
                continue

            try:
                # Convertir hora de asignación a objeto de tiempo
                hora_asignacion = make_aware(
                    datetime.strptime(
                        hora_asignacion.split(".")[0], "%Y-%m-%dT%H:%M:%S"
                    )
                )
                colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
                viaje = Viaje.objects.get(pk=viaje_id)

                # Validación: No permitir asignaciones a ciertos estados
                if (
                    viaje.id_estado.nombre_estado
                    in ["Cancelado", "En Curso", "Completado"]
                    and viaje.id_estado.entidad == "Viaje"
                ):
                    errores.append(
                        f"No se puede asignar al colaborador {rut_colaborador} porque el viaje está en estado '{viaje.id_estado.nombre_estado}'."
                    )
                    continue

                # Validaciones
                if ViajeColaborador.objects.filter(
                    rut_colaborador=rut_colaborador, id_viaje=viaje
                ).exists():
                    errores.append(
                        f"El colaborador {rut_colaborador} ya está asignado a este viaje."
                    )
                    continue

                # Verifica las rutas asignadas al colaborador el mismo día
                viajes_existentes = ViajeColaborador.objects.filter(
                    rut_colaborador=rut_colaborador,
                    id_viaje__fecha_salida=viaje.fecha_salida,
                ).select_related("id_viaje__id_ruta")

                for viaje_existente in viajes_existentes:
                    if viaje_existente.id_viaje.id_ruta == viaje.id_ruta:
                        errores.append(
                            f"El colaborador {rut_colaborador} ya está asignado a esta ruta el mismo día."
                        )
                        break

                    if (
                        viaje_existente.id_viaje.id_ruta.punto_final_latitud
                        == viaje.id_ruta.punto_final_latitud
                    ):
                        errores.append(
                            f"El colaborador {rut_colaborador} ya tiene una asignación con destino a {viaje.id_ruta.descripcion_ruta} el {viaje.fecha_salida}."
                        )
                        break

                if errores:
                    continue

                # Crear la asignación
                ViajeColaborador.objects.create(
                    rut_colaborador=rut_colaborador,
                    id_viaje=viaje,
                    hora_asignacion=hora_asignacion,
                    id_estado_id=estado_id,
                )

                # Actualizar el número de pasajeros en el viaje
                viaje.numero_pasajeros = ViajeColaborador.objects.filter(
                    id_viaje=viaje
                ).count()
                viaje.save()

                # Marcar al colaborador como no disponible
                colaborador.disponible = False
                colaborador.save()

                # Enviar correo con los detalles del viaje
                #   enviar_correo_viaje(colaborador, viaje, hora_asignacion)

                asignados.append(rut_colaborador)

            except Colaborador.DoesNotExist:
                errores.append(f"Colaborador con RUT {rut_colaborador} no encontrado.")
            except Viaje.DoesNotExist:
                errores.append(f"Viaje con ID {viaje_id} no encontrado.")

        if errores:
            return Response(
                {
                    "status": "Asignación parcial completada.",
                    "asignados": asignados,
                    "errores": errores,
                },
                status=status.HTTP_207_MULTI_STATUS,
            )

        return Response(
            {
                "status": "Todos los colaboradores asignados correctamente.",
                "asignados": asignados,
            },
            status=status.HTTP_201_CREATED,
        )

    @action(detail=True, methods=["delete"], url_path="viaje/(?P<id_viaje>[^/.]+)")
    def delete_colaborador_viaje(self, request, rut_colaborador=None, id_viaje=None):
        """
        Elimina un colaborador específico de un viaje específico y envía un correo notificando la cancelación.
        """
        try:
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            viaje = Viaje.objects.get(pk=id_viaje)
            asignacion = ViajeColaborador.objects.get(
                rut_colaborador=colaborador.rut_colaborador, id_viaje=viaje
            )
            asignacion.delete()

            # Actualizar el número de pasajeros en el viaje
            viaje.numero_pasajeros = ViajeColaborador.objects.filter(
                id_viaje=viaje
            ).count()
            viaje.save()

            # Enviar correo notificando la cancelación de la asignación
            enviar_correo_cancelacion_viaje(colaborador, viaje)

            return Response(
                {"status": "Colaborador eliminado correctamente del viaje."},
                status=status.HTTP_204_NO_CONTENT,
            )

        except Colaborador.DoesNotExist:
            return Response(
                {"error": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )
        except ViajeColaborador.DoesNotExist:
            return Response(
                {"error": "Asignación no encontrada."}, status=status.HTTP_404_NOT_FOUND
            )
        # Nueva acción para listar los viajes programados de un colaborador

    # Nueva acción para listar los viajes programados de un colaborador
    @action(detail=True, methods=["get"], url_path="viajes-programados")
    def viajes_programados(self, request, rut_colaborador=None):
        """
        Endpoint para obtener los viajes programados de un colaborador específico,
        con opción de filtrar por id_viaje.
        """
        try:
            # Buscar el colaborador por su rut
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)

            # Obtener el parámetro id_viaje para filtrar
            id_viaje = request.query_params.get("id_viaje", None)

            # Filtrar los viajes asignados al colaborador
            viajes_asignados = ViajeColaborador.objects.filter(
                rut_colaborador=colaborador.rut_colaborador
            )

            # Aplicar el filtro por id_viaje si está presente
            if id_viaje:
                viajes_asignados = viajes_asignados.filter(id_viaje__id=id_viaje)

            if not viajes_asignados.exists():
                return Response(
                    {
                        "detail": "No se encontraron viajes programados para este colaborador con el filtro proporcionado."
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Serializar los viajes asignados
            viajes_data = []
            for viaje_colaborador in viajes_asignados:
                viaje = viaje_colaborador.id_viaje
                viaje_serializer = ViajeSerializer(
                    viaje, context={"colaborador": colaborador}
                )  # Pasar el colaborador en el contexto
                viaje_data = viaje_serializer.data
                viaje_data["hora_asignacion"] = (
                    viaje_colaborador.hora_asignacion.strftime("%Y-%m-%d %H:%M:%S")
                    if viaje_colaborador.hora_asignacion
                    else None
                )  # Agregar la hora de asignación formateada
                viajes_data.append(viaje_data)

            return Response(viajes_data, status=status.HTTP_200_OK)

        except Colaborador.DoesNotExist:
            return Response(
                {"detail": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )

    @action(detail=True, methods=["post"], url_path="dejar-calificacion")
    def dejar_calificacion(self, request, rut_colaborador=None):
        """
        Permite que el colaborador deje una calificación y comentario para el viaje.
        """
        # Verificar que el usuario autenticado coincide con el rut_colaborador
        if request.user.rut != rut_colaborador:
            raise PermissionDenied(
                "Solo el colaborador autenticado y asignado a este viaje tiene permiso para realizar esta acción."
            )

        try:
            # Obtener el colaborador y el viaje
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            id_viaje = request.data.get("id_viaje")
            viaje = Viaje.objects.get(id=id_viaje)

            # Validar que el colaborador esté asignado al viaje
            if not ViajeColaborador.objects.filter(
                rut_colaborador=rut_colaborador, id_viaje=viaje
            ).exists():
                return Response(
                    {
                        "detail": "El colaborador no está asignado a este viaje y no puede dejar una calificación."
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Validar si el colaborador ya dejó una calificación para el viaje
            if CalificacionComentario.objects.filter(
                colaborador=colaborador, viaje=viaje
            ).exists():
                return Response(
                    {"detail": "Ya existe una calificación para este viaje."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Crear la calificación
            serializer = CalificacionComentarioSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save(colaborador=colaborador, viaje=viaje)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Colaborador.DoesNotExist:
            return Response(
                {"detail": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Viaje.DoesNotExist:
            return Response(
                {"detail": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )


class GenerarQRView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, id_viaje, rut_colaborador):
        """
        Genera un código QR para un colaborador específico en un viaje.
        """
        try:
            # Verificar que el usuario autenticado es el colaborador solicitado
            if request.user.rut != rut_colaborador:
                return Response(
                    {
                        "error": "Acceso denegado. Solo el colaborador asignado puede generar el QR."
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Obtener colaborador, viaje y asignación
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            viaje = Viaje.objects.get(id=id_viaje)
            asignacion = ViajeColaborador.objects.filter(
                rut_colaborador=rut_colaborador, id_viaje=viaje
            ).first()

            # Validar que el colaborador esté asignado al viaje
            if not asignacion:
                return Response(
                    {"error": "El colaborador no está asignado a este viaje."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Verificar si el QR ya fue escaneado
            if asignacion.qr_escaneado:
                return Response(
                    {"error": "El código QR ya ha sido escaneado para este viaje."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Generar el código QR
            qr_data = generar_codigo_qr(colaborador, viaje)
            qr_code_base64 = qr_data.get("qr_code")
            qr_token = qr_data.get("qr_token")
            qr_timestamp = qr_data.get("qr_timestamp")

            # Marcar el código QR como generado (opcional si decides mantener este atributo)
            asignacion.qr_generado = True
            asignacion.save()

            return Response(
                {
                    "qr_code": qr_code_base64,
                    "qr_token": qr_token,
                    "qr_timestamp": qr_timestamp,
                },
                status=status.HTTP_200_OK,
            )

        except Colaborador.DoesNotExist:
            return Response(
                {"error": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )


class ValidarQRView(APIView):
    """
    Valida el QR escaneado, actualiza el estado del colaborador y registra el escaneo.
    """

    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        request_body=ValidarQRSerializer,
        responses={
            200: "Asistencia confirmada",
            400: "Error en la solicitud",
            404: "No encontrado",
        },
    )
    def post(self, request):
        serializer = ValidarQRSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Obtener datos validados del QR
        rut_colaborador = serializer.validated_data["rut_colaborador"]
        id_viaje = serializer.validated_data["id_viaje"]
        rut_conductor = serializer.validated_data["rut_conductor"]

        # Verificación del conductor autenticado
        if request.user.rut != rut_conductor:
            return Response(
                {"error": "Acceso denegado. El QR pertenece a otro conductor."},
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            # Obtener colaborador, viaje y conductor
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            viaje = Viaje.objects.get(id=id_viaje)
            conductor = Conductor.objects.get(rut_conductor=rut_conductor)

            # Validar si el colaborador está asignado al viaje
            asignacion = ViajeColaborador.objects.filter(
                rut_colaborador=colaborador.rut_colaborador, id_viaje=viaje
            ).first()

            if not asignacion:
                return Response(
                    {"error": "El colaborador no está asignado a este viaje."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Validar que el QR no haya sido ya escaneado
            if asignacion.qr_escaneado:
                return Response(
                    {"error": "El código QR ya ha sido escaneado."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Validar que el QR pertenezca al colaborador y al viaje
            qr_token = request.data.get("qr_token", "")
            qr_timestamp = int(
                request.data.get("qr_timestamp", 0)
            )  # Se mantiene sin verificación de expiración
            valid_token = hashlib.sha256(
                f"{rut_colaborador}-{viaje.id}-{qr_timestamp}".encode()
            ).hexdigest()

            if qr_token != valid_token:
                return Response(
                    {"error": "El código QR no coincide con el colaborador o viaje."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Zona horaria de Santiago, Chile
            santiago_tz = pytz.timezone("America/Santiago")

            # Validar que el escaneo se realice en la fecha del viaje
            fecha_actual = now().astimezone(santiago_tz).date()
            if fecha_actual != viaje.fecha_salida:
                return Response(
                    {
                        "error": "El escaneo solo se puede realizar en la fecha programada del viaje."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Verificar la existencia de RutaViaje asociada
            ruta_viaje = RutaViaje.objects.filter(id_viaje=viaje).first()
            if not ruta_viaje:
                return Response(
                    {"error": "Ruta asociada al viaje no encontrada."},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Si todo es correcto, marcar el QR como escaneado y registrar la asistencia
            asignacion.qr_escaneado = True
            asignacion.save()

            # Actualizar la hora de recogida o llegada en RutaViaje
            hora_actual = timezone.now()
            if viaje.tipo_viaje.tipo == 1:  # 1 representa "Ida"
                ruta_viaje.hora_real_recogida = hora_actual
            elif viaje.tipo_viaje.tipo == 2:  # 2 representa "Vuelta"
                ruta_viaje.hora_real_llegada = hora_actual

            ruta_viaje.save()

            # Cambiar estado del viaje a "En Curso"
            estado_en_curso = Estado.objects.filter(
                nombre_estado="En Curso", entidad="Viaje"
            ).first()
            if estado_en_curso:
                viaje.id_estado = estado_en_curso
                viaje.save()

            # Registrar el escaneo en el log
            LogEscaneoQR.objects.create(
                conductor=conductor,
                colaborador=colaborador,
                viaje=viaje,
                resultado="Asistencia confirmada",
            )

            return Response(
                {"status": "Asistencia confirmada"}, status=status.HTTP_200_OK
            )

        except Colaborador.DoesNotExist:
            return Response(
                {"error": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Viaje.DoesNotExist:
            return Response(
                {"error": "Viaje no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )
        except Conductor.DoesNotExist:
            return Response(
                {"error": "Conductor no encontrado."}, status=status.HTTP_404_NOT_FOUND
            )


class LogEscaneoQRViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = LogEscaneoQR.objects.all()
    serializer_class = LogEscaneoQRSerializer
    permission_classes = [IsAuthenticated]


class IncidenciaViajeViewSet(viewsets.ModelViewSet):
    queryset = IncidenciaViaje.objects.all()
    serializer_class = IncidenciaViajeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        id_estado = self.request.query_params.get("id_estado")

        # Aplicar filtro por id_estado si está presente en los parámetros de la solicitud
        if id_estado:
            queryset = queryset.filter(id_estado__id=id_estado)

        return queryset

    def create(self, request, *args, **kwargs):
        rut_colaborador = request.data.get("rut_colaborador")
        viaje_id = request.data.get("id_viaje")

        # Validar que el colaborador autenticado sea el mismo que el colaborador de la solicitud
        if request.user.rut != rut_colaborador:
            return Response(
                {
                    "detail": "Acceso denegado. Solo el colaborador asignado puede reportar la incidencia."
                },
                status=status.HTTP_403_FORBIDDEN,
            )

        # Verificar que el viaje exista y pertenezca al colaborador
        try:
            viaje = Viaje.objects.get(
                id=viaje_id,
                viajecolaborador__rut_colaborador=rut_colaborador,
            )
        except Viaje.DoesNotExist:
            return Response(
                {"detail": "Viaje no encontrado o no pertenece al colaborador."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Comentamos la validación de duplicados para permitir múltiples incidencias en el mismo viaje
        # if IncidenciaViaje.objects.filter(
        #     rut_colaborador__rut_colaborador=rut_colaborador,
        #     id_viaje=viaje,
        # ).exists():
        #     return Response(
        #         {"detail": "Ya existe una incidencia para este viaje."},
        #         status=status.HTTP_400_BAD_REQUEST,
        #     )

        return super().create(request, *args, **kwargs)


class LogIncidenciaViajeCreateView(generics.ListCreateAPIView):
    serializer_class = LogIncidenciaViajeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        id_incidencia = self.request.query_params.get("id_incidencia")
        if id_incidencia:
            return LogIncidenciaViaje.objects.filter(id_incidencia=id_incidencia)
        return LogIncidenciaViaje.objects.filter(
            id_incidencia__rut_colaborador__rut_colaborador=self.request.user.rut
        )

    def perform_create(self, serializer):
        colaborador = Colaborador.objects.get(rut_colaborador=self.request.user.rut)
        incidencia = serializer.validated_data["id_incidencia"]

        if not self.request.user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists():
            if (
                incidencia.rut_colaborador.rut_colaborador
                != colaborador.rut_colaborador
            ):
                raise ValidationError(
                    "No tienes permiso para añadir un log a esta incidencia."
                )

        log = serializer.save(rut_colaborador=colaborador)

        if self.request.user.groups.filter(name="Logística").exists():
            santiago_tz = pytz.timezone("America/Santiago")
            incidencia.fecha_ultima_modificacion = make_aware(
                datetime.now(), timezone=santiago_tz
            )
            incidencia.id_estado = log.id_estado
            incidencia.save(update_fields=["fecha_ultima_modificacion", "id_estado"])


class ReporteAsistenciaViewSet(viewsets.ViewSet):
    """
    ViewSet para generar reportes de asistencia de los colaboradores por tipo de viaje (ida o vuelta),
    y permite filtrar por rango de fechas y obtener un consolidado general.
    """

    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                "fecha_inicio",
                openapi.IN_QUERY,
                description="Fecha de inicio del rango en formato 'YYYY-MM-DD'.",
                type=openapi.TYPE_STRING,
                format="date",
            ),
            openapi.Parameter(
                "fecha_fin",
                openapi.IN_QUERY,
                description="Fecha de fin del rango en formato 'YYYY-MM-DD'.",
                type=openapi.TYPE_STRING,
                format="date",
            ),
            openapi.Parameter(
                "intervalo",
                openapi.IN_QUERY,
                description="Intervalo de tiempo para el consolidado ('dia', 'mes', 'anio').",
                type=openapi.TYPE_STRING,
                default="mes",
            ),
        ],
        responses={
            200: openapi.Response(
                description="Reporte de asistencia generado con éxito",
                examples={
                    "application/json": {
                        "detalle_asistencias": [
                            {
                                "rut_colaborador": "18952307-6",
                                "nombres": "Sebastian Ignacio",
                                "apellido_paterno": "Ibacache",
                                "apellido_materno": "Zamorano",
                                "asistencias_ida": 0,
                                "inasistencias_ida": 1,
                                "asistencias_vuelta": 0,
                                "inasistencias_vuelta": 0,
                                "total_asistencias": 0,
                                "total_inasistencias": 1,
                            }
                        ],
                        "consolidado": [
                            {
                                "fecha": "2024-11",
                                "total_asistencias_ida": 0,
                                "total_inasistencias_ida": 1,
                                "total_asistencias_vuelta": 0,
                                "total_inasistencias_vuelta": 0,
                                "total_asistencias": 0,
                                "total_inasistencias": 1,
                            }
                        ],
                    }
                },
            ),
            400: "Solicitud incorrecta. Verifique los parámetros.",
        },
    )
    @action(detail=False, methods=["get"], url_path="asistencias")
    def reporte_asistencias(self, request):
        # Obtener parámetros de filtro de fechas y tipo de intervalo para el consolidado
        fecha_inicio = request.query_params.get("fecha_inicio")
        fecha_fin = request.query_params.get("fecha_fin")
        tipo_intervalo = request.query_params.get(
            "intervalo", "mes"
        )  # "dia", "mes" o "anio"

        # Convertir las fechas a objetos datetime si se proporcionan
        if fecha_inicio:
            fecha_inicio = datetime.strptime(fecha_inicio, "%Y-%m-%d")
        # Fecha actual (límite superior)
        fecha_actual = now().date()
        if fecha_fin:
            fecha_fin = datetime.strptime(
                fecha_fin, "%Y-%m-%d"
            ).date()  # Asegurarnos que sea date
        else:
            fecha_fin = fecha_actual

        # Validar si fecha_fin excede la fecha actual
        if fecha_fin > fecha_actual:
            return Response(
                {
                    "error": "La fecha de fin no puede ser una fecha futura. Seleccione una fecha válida."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Crear filtro de rango de fechas solo si ambas fechas están presentes
        rango_fechas = (fecha_inicio, fecha_fin) if fecha_inicio and fecha_fin else None

        # Filtrar solo los colaboradores que tienen al menos un viaje asignado
        colaboradores_viajes = (
            ViajeColaborador.objects.filter(
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q()
            )
            .values("rut_colaborador")
            .distinct()
        )

        # Obtener las asistencias e inasistencias para viajes de ida y vuelta
        ida_asistencias = (
            ViajeColaborador.objects.filter(
                qr_escaneado=True,
                id_viaje__tipo_viaje__tipo=1,
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q(),
                rut_colaborador__in=colaboradores_viajes,
            )
            .values("rut_colaborador")
            .annotate(asistencias_ida=Count("id"))
        )

        vuelta_asistencias = (
            ViajeColaborador.objects.filter(
                qr_escaneado=True,
                id_viaje__tipo_viaje__tipo=2,
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q(),
                rut_colaborador__in=colaboradores_viajes,
            )
            .values("rut_colaborador")
            .annotate(asistencias_vuelta=Count("id"))
        )

        # Obtener inasistencias
        ida_inasistencias = (
            ViajeColaborador.objects.filter(
                qr_escaneado=False,
                id_viaje__tipo_viaje__tipo=1,
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q(),
                rut_colaborador__in=colaboradores_viajes,
            )
            .values("rut_colaborador")
            .annotate(inasistencias_ida=Count("id"))
        )

        vuelta_inasistencias = (
            ViajeColaborador.objects.filter(
                qr_escaneado=False,
                id_viaje__tipo_viaje__tipo=2,
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q(),
                rut_colaborador__in=colaboradores_viajes,
            )
            .values("rut_colaborador")
            .annotate(inasistencias_vuelta=Count("id"))
        )

        # Construcción del reporte detallado
        data = []
        for colaborador_data in colaboradores_viajes:
            rut_colaborador = colaborador_data["rut_colaborador"]
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)

            asistencias_ida = next(
                (
                    item["asistencias_ida"]
                    for item in ida_asistencias
                    if item["rut_colaborador"] == rut_colaborador
                ),
                0,
            )
            inasistencias_ida = next(
                (
                    item["inasistencias_ida"]
                    for item in ida_inasistencias
                    if item["rut_colaborador"] == rut_colaborador
                ),
                0,
            )
            asistencias_vuelta = next(
                (
                    item["asistencias_vuelta"]
                    for item in vuelta_asistencias
                    if item["rut_colaborador"] == rut_colaborador
                ),
                0,
            )
            inasistencias_vuelta = next(
                (
                    item["inasistencias_vuelta"]
                    for item in vuelta_inasistencias
                    if item["rut_colaborador"] == rut_colaborador
                ),
                0,
            )

            total_asistencias = asistencias_ida + asistencias_vuelta
            total_inasistencias = inasistencias_ida + inasistencias_vuelta

            data.append(
                {
                    "rut_colaborador": rut_colaborador,
                    "nombres": colaborador.nombres,
                    "apellido_paterno": colaborador.apellido_paterno,
                    "apellido_materno": colaborador.apellido_materno,
                    "asistencias_ida": asistencias_ida,
                    "inasistencias_ida": inasistencias_ida,
                    "asistencias_vuelta": asistencias_vuelta,
                    "inasistencias_vuelta": inasistencias_vuelta,
                    "total_asistencias": total_asistencias,
                    "total_inasistencias": total_inasistencias,
                }
            )

        # Cálculo del consolidado general por día, mes o año
        if tipo_intervalo == "mes":
            fecha_trunc = TruncMonth("id_viaje__fecha_salida")
            date_format = "%Y-%m"
        elif tipo_intervalo == "anio":
            fecha_trunc = TruncYear("id_viaje__fecha_salida")
            date_format = "%Y"
        else:
            fecha_trunc = TruncDay("id_viaje__fecha_salida")
            date_format = "%Y-%m-%d"

        consolidado = (
            ViajeColaborador.objects.filter(
                id_viaje__fecha_salida__range=rango_fechas if rango_fechas else Q()
            )
            .annotate(fecha=fecha_trunc)
            .filter(fecha__lte=fecha_fin)  # Filtrar solo fechas hasta la actual
            .values("fecha")
            .annotate(
                total_asistencias_ida=Count(
                    "id", filter=Q(qr_escaneado=True, id_viaje__tipo_viaje__tipo=1)
                ),
                total_inasistencias_ida=Count(
                    "id", filter=Q(qr_escaneado=False, id_viaje__tipo_viaje__tipo=1)
                ),
                total_asistencias_vuelta=Count(
                    "id", filter=Q(qr_escaneado=True, id_viaje__tipo_viaje__tipo=2)
                ),
                total_inasistencias_vuelta=Count(
                    "id", filter=Q(qr_escaneado=False, id_viaje__tipo_viaje__tipo=2)
                ),
            )
            .order_by("fecha")
        )

        # Formatear las fechas en el consolidado y agregar totales
        formatted_consolidado = [
            {
                "fecha": item["fecha"].strftime(date_format),
                "total_asistencias_ida": item["total_asistencias_ida"],
                "total_inasistencias_ida": item["total_inasistencias_ida"],
                "total_asistencias_vuelta": item["total_asistencias_vuelta"],
                "total_inasistencias_vuelta": item["total_inasistencias_vuelta"],
                "total_asistencias": item["total_asistencias_ida"]
                + item["total_asistencias_vuelta"],
                "total_inasistencias": item["total_inasistencias_ida"]
                + item["total_inasistencias_vuelta"],
            }
            for item in consolidado
        ]

        # Agregar consolidado al resultado
        response_data = {
            "detalle_asistencias": data,
            "consolidado": formatted_consolidado,
        }

        return Response(response_data, status=status.HTTP_200_OK)


class ReporteUsoTransporteViewSet(viewsets.ViewSet):
    permission_classes = [permissions.IsAuthenticated]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                "year",
                openapi.IN_QUERY,
                description="Año para filtrar los viajes (formato YYYY)",
                type=openapi.TYPE_INTEGER,
                required=False,
            ),
            openapi.Parameter(
                "month",
                openapi.IN_QUERY,
                description="Mes para filtrar los viajes (formato MM)",
                type=openapi.TYPE_INTEGER,
                required=False,
            ),
        ],
        responses={
            200: openapi.Response(
                description="Reporte de uso de transporte filtrado por año y mes",
                examples={
                    "application/json": {
                        "vehiculo_mas_usado": [
                            {
                                "id_vehiculo": "1",
                                "modelo_vehiculo": "Sprinter",
                                "patente_vehiculo": "MBVAN001",
                                "marca_vehiculo": "Mercedes-Benz",
                                "capacidad_ocupantes": 9,
                                "total": 10,
                            }
                        ],
                        "conductor_mas_frecuente": [
                            {
                                "id_conductor": "12345678-9",
                                "nombre_conductor": "Carlos",
                                "apellido_paterno_conductor": "Rodríguez",
                                "apellido_materno_conductor": "Hernández",
                                "email_conductor": "carlos.rodriguez@sototix.cl",
                                "telefono_conductor": "987654321",
                                "total": 15,
                            }
                        ],
                        "ruta_mas_transitada": [
                            {
                                "id_ruta": "1",
                                "descripcion_ruta": "Aeropuerto Santiago",
                                "punto_inicial_latitud": "-33.024496",
                                "punto_inicial_longitud": "-71.551809",
                                "punto_final_latitud": "-33.411015",
                                "punto_final_longitud": "-70.793087",
                                "total": 20,
                            }
                        ],
                    }
                },
            ),
            400: "Solicitud inválida. Verifique los parámetros.",
        },
    )
    @action(detail=False, methods=["get"], url_path="uso-transporte")
    def uso_transporte(self, request):
        """
        Endpoint para generar un reporte del uso de transporte, filtrado opcionalmente
        por año y mes.
        """
        # Obtener parámetros de filtro
        year = request.query_params.get("year")
        month = request.query_params.get("month")

        # Crear un filtro dinámico basado en los parámetros recibidos
        filter_conditions = Q()
        if year:
            filter_conditions &= Q(fecha_salida__year=year)
        if month:
            filter_conditions &= Q(fecha_salida__month=month)

        # Consulta para obtener el vehículo más usado con filtros aplicados
        vehiculo_mas_usado = (
            Viaje.objects.filter(filter_conditions)
            .values(
                "id_vehiculo",
                "id_vehiculo__modelo",
                "id_vehiculo__patente",
                "id_vehiculo__marca",
                "id_vehiculo__capacidad_ocupantes",
            )
            .annotate(total=Count("id_vehiculo"))
            .order_by("-total")
        )

        # Consulta para obtener el conductor más frecuente con filtros aplicados
        conductor_mas_frecuente = (
            Viaje.objects.filter(filter_conditions)
            .values(
                "id_conductor",
                "id_conductor__nombres",
                "id_conductor__apellido_paterno",
                "id_conductor__apellido_materno",
                "id_conductor__email",
                "id_conductor__telefono",
            )
            .annotate(total=Count("id_conductor"))
            .order_by("-total")
        )

        # Consulta para obtener la ruta más transitada con filtros aplicados
        ruta_mas_transitada = (
            Viaje.objects.filter(filter_conditions)
            .values(
                "id_ruta",
                "id_ruta__descripcion_ruta",
                "id_ruta__punto_inicial_latitud",
                "id_ruta__punto_inicial_longitud",
                "id_ruta__punto_final_latitud",
                "id_ruta__punto_final_longitud",
            )
            .annotate(total=Count("id_ruta"))
            .order_by("-total")
        )

        # Serialización de los datos
        vehiculo_serializer = ReporteUsoTransporteSerializer(
            vehiculo_mas_usado, many=True
        )
        conductor_serializer = ReporteUsoTransporteSerializer(
            conductor_mas_frecuente, many=True
        )
        ruta_serializer = ReporteUsoTransporteSerializer(ruta_mas_transitada, many=True)

        # Estructura de la respuesta
        response_data = {
            "vehiculo_mas_usado": vehiculo_serializer.data,
            "conductor_mas_frecuente": conductor_serializer.data,
            "ruta_mas_transitada": ruta_serializer.data,
        }

        return Response(response_data)


class IncidenciaGeneralViewSet(viewsets.ViewSet):
    """
    ViewSet para listar todas las incidencias (habitaciones y viajes).
    Permite aplicar filtros por año y mes y muestra totales por estado y totales generales.
    """

    permission_classes = [permissions.IsAuthenticated]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                name="year",
                in_=openapi.IN_QUERY,
                description="Año para filtrar las incidencias (formato YYYY).",
                type=openapi.TYPE_INTEGER,
                required=False,
            ),
            openapi.Parameter(
                name="month",
                in_=openapi.IN_QUERY,
                description="Mes para filtrar las incidencias (formato MM).",
                type=openapi.TYPE_INTEGER,
                required=False,
            ),
        ],
        responses={
            200: openapi.Response(
                description="Incidencias filtradas por año, mes o ambos.",
                examples={
                    "application/json": {
                        "habitaciones": {
                            "detalles": [
                                {
                                    "id": 35,
                                    "rut_colaborador": "18952307-6",
                                    "nombres": "Sebastian Ignacio",
                                    "apellido_paterno": "Ibacache",
                                    "apellido_materno": "Zamorano",
                                    "id_asignacion_habitacion": 6344,
                                    "fecha_creacion": "2024-11-14T22:31:44",
                                    "fecha_ultima_modificacion": "2024-11-18T02:21:52",
                                    "id_estado": 102,
                                    "estado_nombre": "Requiere Inspección",
                                    "comentario": "Sigue con fallas...",
                                }
                            ],
                            "totales": {
                                "Cerrada": 3,
                                "En Revisión": 1,
                                "Requiere Inspección": 1,
                            },
                        },
                        "viajes": {
                            "detalles": [
                                {
                                    "id": 1,
                                    "fecha_creacion": "2024-11-11T17:44:14",
                                    "fecha_ultima_modificacion": "2024-11-15T00:52:56",
                                    "rut_colaborador": "18952307-6",
                                    "nombres": "Sebastian Ignacio",
                                    "apellido_paterno": "Ibacache",
                                    "apellido_materno": "Zamorano",
                                    "comentario": "Problemas de limpieza.",
                                    "estado_nombre": "Cerrada",
                                    "id_estado": 105,
                                    "id_viaje": 100,
                                }
                            ],
                            "totales": {"Cerrada": 2},
                        },
                    }
                },
            ),
            400: "Solicitud inválida. Verifica los parámetros.",
        },
    )
    def list(self, request):
        """
        Lista todas las incidencias combinadas con filtros opcionales de año y mes.
        Además, incluye totales por estado y totales generales.
        """
        year = request.query_params.get("year")
        month = request.query_params.get("month")

        # Inicializar consultas
        incidencias_habitaciones = IncidenciaHabitacion.objects.all()
        incidencias_viajes = IncidenciaViaje.objects.all()

        # Aplicar filtros por año y mes
        if year:
            incidencias_habitaciones = incidencias_habitaciones.filter(
                fecha_creacion__year=year
            )
            incidencias_viajes = incidencias_viajes.filter(fecha_creacion__year=year)
        if month:
            incidencias_habitaciones = incidencias_habitaciones.filter(
                fecha_creacion__month=month
            )
            incidencias_viajes = incidencias_viajes.filter(fecha_creacion__month=month)

        # Totales por estado (habitaciones)
        totales_habitaciones = (
            incidencias_habitaciones.values("id_estado__nombre_estado")
            .annotate(total=Count("id"))
            .order_by("id_estado__nombre_estado")
        )

        # Totales por estado (viajes)
        totales_viajes = (
            incidencias_viajes.values("id_estado__nombre_estado")
            .annotate(total=Count("id"))
            .order_by("id_estado__nombre_estado")
        )

        # Serializar datos
        serializer_habitaciones = IncidenciaHabitacionSerializer(
            incidencias_habitaciones, many=True
        )
        serializer_viajes = IncidenciaViajeSerializer(incidencias_viajes, many=True)

        # Formatear totales como un diccionario
        totales_habitaciones_dict = {
            total["id_estado__nombre_estado"]: total["total"]
            for total in totales_habitaciones
        }
        totales_viajes_dict = {
            total["id_estado__nombre_estado"]: total["total"]
            for total in totales_viajes
        }

        # Cálculo de totales generales
        total_habitaciones = incidencias_habitaciones.count()
        total_viajes = incidencias_viajes.count()

        # Combinar resultados
        datos_combinados = {
            "habitaciones": {
                "detalles": serializer_habitaciones.data,
                "totales": {
                    "por_estado": totales_habitaciones_dict,
                    "total": total_habitaciones,
                },
            },
            "viajes": {
                "detalles": serializer_viajes.data,
                "totales": {
                    "por_estado": totales_viajes_dict,
                    "total": total_viajes,
                },
            },
        }

        return Response(datos_combinados, status=status.HTTP_200_OK)
