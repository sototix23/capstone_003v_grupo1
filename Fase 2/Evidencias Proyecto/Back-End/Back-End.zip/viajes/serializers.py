from rest_framework import serializers
from .models import (
    Estado,
    Ruta,
    Viaje,
    RutaViaje,
    ViajeColaborador,
    TipoViaje,
    CalificacionComentario,
    LogEscaneoQR,
    IncidenciaViaje,
    LogIncidenciaViaje,
    Colaborador,
)
from taxista.models import Vehiculo, Conductor
from taxista.serializers import ConductorSerializer
from django.utils import timezone


class EstadoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Estado
        fields = "__all__"


class RutaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ruta
        fields = "__all__"


class TipoViajeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TipoViaje
        fields = ["id", "descripcion"]  # Solo devolver el id y la descripción


class ViajeSerializer(serializers.ModelSerializer):
    # Campos ForeignKey para realizar GET y POST correctamente
    id_estado = serializers.PrimaryKeyRelatedField(queryset=Estado.objects.all())
    id_ruta = serializers.PrimaryKeyRelatedField(queryset=Ruta.objects.all())
    id_vehiculo = serializers.PrimaryKeyRelatedField(
        queryset=Vehiculo.objects.all(), required=False, allow_null=True
    )
    id_conductor = serializers.PrimaryKeyRelatedField(
        queryset=Conductor.objects.all(), required=False, allow_null=True
    )
    tipo_viaje = serializers.PrimaryKeyRelatedField(queryset=TipoViaje.objects.all())
    # Campos para incidencia
    incidencia_activa = serializers.SerializerMethodField()
    incidencia = serializers.SerializerMethodField()
    # Campo para datos del colaborador
    colaboradores_qr = serializers.SerializerMethodField()
    logs_escaneo = serializers.SerializerMethodField()  # Nuevo campo para los logs

    class Meta:
        model = Viaje
        fields = [
            "id",
            "codigo_viaje",
            "fecha_salida",
            "hora_salida",
            "fecha_llegada",
            "hora_llegada",
            "fecha_creacion",
            "fecha_modificacion",
            "punto_partida",
            "punto_destino",
            "numero_pasajeros",
            "kilometros",
            "valor_estimado",
            "estado_inicio_real",
            "estado_fin_real",
            "motivo_cancelacion",
            "observaciones",
            "id_viaje_anterior",
            "tarifa_base",
            "peajes",
            "tarifa_total",
            "confirmado_por_conductor",
            "usuario_creador",
            "usuario_modificador",
            "id_estado",
            "id_ruta",
            "id_vehiculo",
            "id_conductor",
            "tipo_viaje",
            "tiempo_estimado",
            "incidencia_activa",
            "incidencia",
            "colaboradores_qr",
            "logs_escaneo",
        ]

    def get_logs_escaneo(self, obj):
        """
        Retorna los logs de escaneo QR asociados al viaje y filtrados por el colaborador.
        """
        colaborador = self.context.get(
            "colaborador"
        )  # Obtén el colaborador del contexto
        if colaborador:
            logs = LogEscaneoQR.objects.filter(viaje=obj, colaborador=colaborador)
            return LogEscaneoQRSerializer(logs, many=True).data
        return []

    def get_colaboradores_qr(self, obj):
        """
        Obtiene la información de QR para cada colaborador asignado al viaje,
        filtrando por el colaborador especificado en el contexto si está presente.
        """
        colaborador = self.context.get(
            "colaborador"
        )  # Obtiene el colaborador del contexto
        if colaborador:
            colaboradores = ViajeColaborador.objects.filter(
                id_viaje=obj, rut_colaborador=colaborador.rut_colaborador
            )
        else:
            colaboradores = ViajeColaborador.objects.filter(id_viaje=obj)

        return ViajeColaboradorSerializer(colaboradores, many=True).data

    def get_colaborador(self, obj):
        colaborador = self.context.get("colaborador")
        if colaborador:
            return {
                "rut_colaborador": colaborador.rut_colaborador,
                "nombres": colaborador.nombres,
                "apellido_paterno": colaborador.apellido_paterno,
                "apellido_materno": colaborador.apellido_materno,
                "email": colaborador.email,
                "situacion_laboral": colaborador.situacion_laboral,
            }
        return None

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        # Formatear fechas y horas sin microsegundos
        if instance.fecha_creacion:
            representation["fecha_creacion"] = instance.fecha_creacion.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        if instance.fecha_modificacion:
            representation["fecha_modificacion"] = instance.fecha_modificacion.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        if instance.hora_salida:
            representation["hora_salida"] = instance.hora_salida.strftime("%H:%M:%S")

        # Cambiar las claves en la representación del GET
        representation["estado"] = (
            instance.id_estado.nombre_estado if instance.id_estado else None
        )
        representation["ruta"] = (
            {"id": instance.id_ruta.id, "nombre": instance.id_ruta.descripcion_ruta}
            if instance.id_ruta
            else None
        )

        # Agregar representación completa del conductor con foto
        if instance.id_conductor:
            representation["conductor"] = ConductorSerializer(
                instance.id_conductor
            ).data
        else:
            representation["conductor"] = None

        # Manejar el viaje anterior si es ForeignKey
        representation["viaje_anterior"] = (
            instance.id_viaje_anterior.codigo_viaje
            if instance.id_viaje_anterior
            and isinstance(instance.id_viaje_anterior, Viaje)
            else None
        )

        # Reemplazar usuario_creador y usuario_modificador por emails
        representation["usuario_creador"] = (
            instance.usuario_creador.email if instance.usuario_creador else None
        )
        representation["usuario_modificador"] = (
            instance.usuario_modificador.email
            if instance.usuario_modificador
            else "Sin modificaciones"
        )

        # Mostrar la descripción del tipo de viaje en el GET
        representation["tipo_viaje"] = (
            {
                "id": instance.tipo_viaje.id,
                "nombre": instance.tipo_viaje.descripcion,
            }
            if instance.tipo_viaje
            else {"id": None, "nombre": "No especificado"}
        )

        # Mostrar tiempo_estimado solo si no está vacío
        representation["tiempo_estimado"] = (
            instance.tiempo_estimado if instance.tiempo_estimado else "No especificado"
        )

        # Eliminar los campos de ID innecesarios para el GET
        del representation["id_estado"]
        del representation["id_ruta"]
        del representation["id_vehiculo"]
        del representation["id_conductor"]
        del representation["id_viaje_anterior"]

        return representation

    def get_incidencia_activa(self, obj):
        """
        Retorna True si el viaje tiene una incidencia activa para el colaborador asociado.
        """
        estados_activos = [100, 101, 102, 103]  # Estados considerados como activos
        colaborador = self.context.get(
            "colaborador"
        )  # Pasar colaborador en el contexto
        if colaborador:
            return IncidenciaViaje.objects.filter(
                rut_colaborador=colaborador,
                id_viaje=obj,
                id_estado__id__in=estados_activos,
            ).exists()
        return False

    def get_incidencia(self, obj):
        estados_activos = [100, 101, 102, 103]
        colaborador = self.context.get("colaborador")
        if colaborador:
            incidencia = IncidenciaViaje.objects.filter(
                rut_colaborador=colaborador,
                id_viaje=obj,
                id_estado__id__in=estados_activos,
            ).first()
            if incidencia:
                return {
                    "id": incidencia.id,
                    "estado": incidencia.id_estado.id,
                    "nombre_estado": incidencia.id_estado.nombre_estado,
                    "comentario": incidencia.comentario,
                }
        return None


class RutaViajeSerializer(serializers.ModelSerializer):
    class Meta:
        model = RutaViaje
        fields = [
            "id",
            "id_viaje",
            "latitud",
            "longitud",
            "orden",
            "hora_estimada_recogida",  # Nuevo campo
            "hora_real_recogida",  # Nuevo campo
            "hora_real_llegada",  # Nuevo campo
            "hora_estimada_llegada",  # Nuevo campo
            "rut_colaborador",
            "id_direccion",  # Nuevo campo
        ]

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if not representation.get("id_direccion"):
            representation["id_direccion"] = "Sin Dirección"  # Valor predeterminado
        return representation


class ViajeColaboradorSerializer(serializers.ModelSerializer):
    class Meta:
        model = ViajeColaborador
        fields = [
            "rut_colaborador",
            "id_viaje",
            "hora_asignacion",
            "id_estado",
            "qr_escaneado",
        ]

    def to_representation(self, instance):
        """
        Personaliza la salida para que en vez del ID del estado se devuelva el nombre.
        """
        representation = super().to_representation(instance)
        representation["estado"] = instance.id_estado.nombre_estado
        del representation["id_estado"]  # Eliminamos el ID del estado para el GET

        # Formatear hora_asignacion sin microsegundos
        if instance.hora_asignacion:
            representation["hora_asignacion"] = instance.hora_asignacion.strftime(
                "%Y-%m-%d %H:%M:%S"
            )

        # Buscar el colaborador por el rut_colaborador
        colaborador = Colaborador.objects.filter(
            rut_colaborador=instance.rut_colaborador
        ).first()

        if colaborador:
            # Añadir nombres y apellidos del colaborador
            representation["nombres"] = colaborador.nombres
            representation["apellido_paterno"] = colaborador.apellido_paterno
            representation["apellido_materno"] = colaborador.apellido_materno
            representation["url_foto"] = (
                colaborador.url_foto
            )  # Añadir url_foto del colaborador

            # Obtener dirección principal del colaborador
            direccion = colaborador.direcciones.filter(es_principal=True).first()
            if direccion:
                representation["comuna"] = direccion.comuna
                representation["region"] = direccion.region
            else:
                representation["comuna"] = None
                representation["region"] = None

            # Obtener el contrato más reciente para obtener el turno
            contrato = colaborador.contratos.order_by("-fecha_ingreso").first()
            if contrato:
                representation["turno"] = contrato.turno
            else:
                representation["turno"] = "N/A"
        else:
            # Si no se encuentra el colaborador, se establece todo como None
            representation["nombres"] = None
            representation["apellido_paterno"] = None
            representation["apellido_materno"] = None
            representation["comuna"] = None
            representation["region"] = None
            representation["turno"] = "N/A"
            representation["url_foto"] = None

        return representation

    def validate_rut_colaborador(self, value):
        """
        Validar que el rut_colaborador exista en la base de datos.
        """
        if not Colaborador.objects.filter(rut_colaborador=value).exists():
            raise serializers.ValidationError("El rut_colaborador no existe.")
        return value


class ValidarQRSerializer(serializers.Serializer):
    rut_colaborador = serializers.CharField(max_length=12)
    id_viaje = serializers.IntegerField()
    rut_conductor = serializers.CharField(max_length=12)

    class Meta:
        fields = ["rut_colaborador", "id_viaje", "rut_conductor"]


class LogEscaneoQRSerializer(serializers.ModelSerializer):
    class Meta:
        model = LogEscaneoQR
        fields = [
            "conductor",
            "colaborador",
            "viaje",
            "fecha_hora_escaneo",
            "resultado",
        ]


class CalificacionComentarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = CalificacionComentario
        fields = ["calificacion", "comentario", "colaborador", "viaje", "fecha"]
        read_only_fields = [
            "colaborador",
            "viaje",
            "fecha",
        ]  # Estos se asignarán automáticamente

    def validate_calificacion(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("La calificación debe estar entre 1 y 5.")
        return value


class IncidenciaViajeSerializer(serializers.ModelSerializer):
    estado_nombre = serializers.CharField(
        source="id_estado.nombre_estado", read_only=True
    )
    fecha_creacion = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    fecha_ultima_modificacion = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    nombres = serializers.CharField(source="rut_colaborador.nombres", read_only=True)
    apellido_paterno = serializers.CharField(
        source="rut_colaborador.apellido_paterno", read_only=True
    )
    apellido_materno = serializers.CharField(
        source="rut_colaborador.apellido_materno", read_only=True
    )

    class Meta:
        model = IncidenciaViaje
        fields = [
            "id",
            "fecha_creacion",
            "fecha_ultima_modificacion",
            "rut_colaborador",
            "nombres",
            "apellido_paterno",
            "apellido_materno",
            "comentario",
            "estado_nombre",
            "id_estado",
            "id_viaje",
        ]

    def get_nombre_completo_colaborador(self, obj):
        return f"{obj.rut_colaborador.nombres} {obj.rut_colaborador.apellido_paterno} {obj.rut_colaborador.apellido_materno}"

    def validate(self, attrs):
        rut_colaborador = attrs.get("rut_colaborador")
        viaje = attrs.get("id_viaje")
        comentario = attrs.get("comentario")
        request_user = self.context["request"].user
        es_logistica_o_admin = request_user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists()
        id_estado = attrs.get("id_estado")

        # Validar acceso
        if rut_colaborador and not (
            request_user.rut == rut_colaborador.rut_colaborador or es_logistica_o_admin
        ):
            raise serializers.ValidationError(
                "Acceso denegado. Solo el colaborador asignado o el equipo de Logística/Administrador pueden gestionar la incidencia."
            )

        # Validar permisos de cambio de estado
        if id_estado:
            if id_estado.id in [101, 102, 103, 104] and not es_logistica_o_admin:
                raise serializers.ValidationError(
                    "Solo el equipo de Logística/Administrador puede asignar los estados 101, 102, 103 y 104."
                )
            if id_estado.id in [100, 105] and es_logistica_o_admin:
                raise serializers.ValidationError(
                    "Solo el colaborador asignado puede asignar los estados 100 y 105."
                )

        # Validar que la incidencia solo pueda reportarse en la fecha de salida del viaje
        if viaje and viaje.fecha_salida != timezone.now().date():
            raise serializers.ValidationError(
                "La incidencia solo puede reportarse en la fecha de salida del viaje."
            )

        # Validar que el comentario no esté vacío, pero solo en caso de creación (POST)
        if self.context["request"].method == "POST":
            if comentario is None or comentario.strip() == "":
                raise serializers.ValidationError("El comentario no puede estar vacío.")

        return attrs

    def update(self, instance, validated_data):
        # Validar que no se pueda actualizar si el estado actual es 105 (Cerrada)
        if instance.id_estado.id == 105:
            raise serializers.ValidationError(
                "No se pueden realizar cambios en una incidencia que ha sido cerrada."
            )

        request = self.context.get("request")
        request_user = request.user
        previous_estado = instance.id_estado

        # Actualizar la incidencia y la fecha de última modificación
        instance = super().update(instance, validated_data)
        instance.fecha_ultima_modificacion = timezone.now()
        instance.save(update_fields=["fecha_ultima_modificacion"])

        # Crear log con mensaje automático si el estado cambia a 101
        if (
            request_user.groups.filter(name__in=["Logística", "Administrador"]).exists()
            and instance.id_estado.id == 101
            and previous_estado != instance.id_estado
        ):
            colaborador = Colaborador.objects.get(rut_colaborador=request_user.rut)
            LogIncidenciaViaje.objects.create(
                id_incidencia=instance,
                rut_colaborador=colaborador,
                comentario="Incidencia en Revisión, pronto lo contactaremos",
                id_estado=instance.id_estado,
            )

        return instance

    def create(self, validated_data):
        # Asignar el estado "Reportada" automáticamente al crear la incidencia
        estado_reportada, created = Estado.objects.get_or_create(
            nombre_estado="Reportada", entidad="Incidencia"
        )
        validated_data["id_estado"] = estado_reportada
        return super().create(validated_data)


class LogIncidenciaViajeSerializer(serializers.ModelSerializer):
    rut_colaborador = serializers.SlugRelatedField(
        slug_field="rut_colaborador",
        queryset=Colaborador.objects.all(),
    )
    estado_nombre = serializers.CharField(
        source="id_estado.nombre_estado", read_only=True
    )
    fecha_comentario = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    nombres = serializers.CharField(source="rut_colaborador.nombres", read_only=True)
    apellido_paterno = serializers.CharField(
        source="rut_colaborador.apellido_paterno", read_only=True
    )
    apellido_materno = serializers.CharField(
        source="rut_colaborador.apellido_materno", read_only=True
    )

    class Meta:
        model = LogIncidenciaViaje
        fields = [
            "id",
            "fecha_comentario",
            "comentario",
            "rut_colaborador",
            "nombres",
            "apellido_paterno",
            "apellido_materno",
            "id_incidencia",
            "id_estado",
            "estado_nombre",
        ]

    def get_nombre_completo_colaborador(self, obj):
        return f"{obj.rut_colaborador.nombres} {obj.rut_colaborador.apellido_paterno} {obj.rut_colaborador.apellido_materno}"

    def validate(self, data):
        request = self.context.get("request")
        incidencia = data["id_incidencia"]
        es_logistica_o_admin = request.user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists()

        if incidencia.id_estado.id == 105:
            raise serializers.ValidationError(
                "No se pueden realizar más cambios en una incidencia que ha sido cerrada."
            )

        if (
            not es_logistica_o_admin
            and incidencia.rut_colaborador.rut_colaborador != request.user.rut
        ):
            raise serializers.ValidationError(
                "Acceso denegado. Solo el colaborador asignado o el equipo de Logística/Administrador pueden gestionar la incidencia."
            )

        if not es_logistica_o_admin:
            estado_id = data.get("id_estado", None)
            if estado_id is not None and estado_id.id != 105:
                raise serializers.ValidationError(
                    "No tienes permiso para cambiar el estado a algo distinto de 'Cerrada'."
                )
            if estado_id is None:
                data["id_estado"] = incidencia.id_estado

        if (
            es_logistica_o_admin
            and data.get("id_estado", None)
            and data["id_estado"].id in [100, 105]
        ):
            raise serializers.ValidationError(
                "El equipo de Logística o Administrador no puede asignar el estado 'Reportada' o 'Cerrada'."
            )

        return data

    def create(self, validated_data):
        log = LogIncidenciaViaje.objects.create(**validated_data)
        incidencia = validated_data["id_incidencia"]
        incidencia.fecha_ultima_modificacion = timezone.now()
        incidencia.save(update_fields=["fecha_ultima_modificacion"])
        return log


class AsistenciaReporteSerializer(serializers.Serializer):
    rut_colaborador = serializers.CharField()
    nombres = serializers.CharField()
    apellido_paterno = serializers.CharField()
    apellido_materno = serializers.CharField()
    asistencias_ida = serializers.IntegerField()
    asistencias_vuelta = serializers.IntegerField()


class ReporteUsoTransporteSerializer(serializers.Serializer):
    # Campos para el vehículo
    id_vehiculo = serializers.CharField(required=False)
    modelo_vehiculo = serializers.CharField(
        source="id_vehiculo__modelo", required=False
    )
    patente_vehiculo = serializers.CharField(
        source="id_vehiculo__patente", required=False
    )
    marca_vehiculo = serializers.CharField(source="id_vehiculo__marca", required=False)
    capacidad_ocupantes = serializers.IntegerField(
        source="id_vehiculo__capacidad_ocupantes", required=False
    )

    # Campos para el conductor
    id_conductor = serializers.CharField(required=False)
    nombre_conductor = serializers.CharField(
        source="id_conductor__nombres", required=False
    )
    apellido_paterno_conductor = serializers.CharField(
        source="id_conductor__apellido_paterno", required=False
    )
    apellido_materno_conductor = serializers.CharField(
        source="id_conductor__apellido_materno", required=False
    )
    email_conductor = serializers.EmailField(
        source="id_conductor__email", required=False
    )
    telefono_conductor = serializers.CharField(
        source="id_conductor__telefono", required=False
    )

    # Campos para la ruta
    id_ruta = serializers.CharField(required=False)
    descripcion_ruta = serializers.CharField(
        source="id_ruta__descripcion_ruta", required=False
    )
    punto_inicial_latitud = serializers.DecimalField(
        source="id_ruta__punto_inicial_latitud",
        max_digits=25,
        decimal_places=15,
        required=False,
    )
    punto_inicial_longitud = serializers.DecimalField(
        source="id_ruta__punto_inicial_longitud",
        max_digits=25,
        decimal_places=15,
        required=False,
    )
    punto_final_latitud = serializers.DecimalField(
        source="id_ruta__punto_final_latitud",
        max_digits=25,
        decimal_places=15,
        required=False,
    )
    punto_final_longitud = serializers.DecimalField(
        source="id_ruta__punto_final_longitud",
        max_digits=25,
        decimal_places=15,
        required=False,
    )

    # Total de uso
    total = serializers.IntegerField()
