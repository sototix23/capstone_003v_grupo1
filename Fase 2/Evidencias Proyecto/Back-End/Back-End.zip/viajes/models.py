from django.utils.timezone import now
import pytz
from datetime import datetime
from django.db import models
from django.conf import settings
from colaboradores.models import Colaborador  # Importar modelo de Colaborador
from taxista.models import (
    Vehiculo,
    Conductor,
)  # Importar modelo Vehiculo desde la app taxista
from .validators import (
    validar_latitud,
    validar_longitud,
    validar_fecha_salida,
    validar_valor_no_negativo,
    validar_numero_pasajeros,
    validar_orden,
)
from django.core.exceptions import ValidationError
from django.utils import timezone


# Modelo Estado
class Estado(models.Model):
    nombre_estado = models.CharField(max_length=255)
    descripcion_estado = models.TextField()  # Campo de descripción para el estado
    entidad = models.CharField(
        max_length=50
    )  # Campo para asociar la entidad del estado

    def __str__(self):
        return self.nombre_estado


# Modelo Ruta
class Ruta(models.Model):
    descripcion_ruta = models.CharField(max_length=255)
    punto_inicial_latitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_latitud]
    )
    punto_inicial_longitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_longitud]
    )
    punto_final_latitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_latitud]
    )
    punto_final_longitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_longitud]
    )

    def __str__(self):
        return self.descripcion_ruta


# Modelo TipoViaje
class TipoViaje(models.Model):
    IDA_VUELTA_CHOICES = [(1, "Ida"), (2, "Vuelta")]

    tipo = models.IntegerField(choices=IDA_VUELTA_CHOICES, unique=True)
    descripcion = models.CharField(max_length=255)

    def __str__(self):
        return dict(self.IDA_VUELTA_CHOICES).get(self.tipo, "Desconocido")


# Modelo Viaje
class Viaje(models.Model):
    codigo_viaje = models.CharField(max_length=50)  # Obligatorio
    fecha_salida = models.DateField()  # Obligatorio
    hora_salida = models.TimeField()  # Obligatorio
    fecha_llegada = models.DateField(
        null=True, blank=True, help_text="Fecha real de llegada del viaje"
    )
    hora_llegada = models.TimeField(
        null=True, blank=True, help_text="Hora real de llegada del viaje"
    )
    fecha_creacion = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    fecha_modificacion = models.DateTimeField(auto_now=True, null=True, blank=True)
    usuario_creador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="viajes_creados",
    )  # Obligatorio
    usuario_modificador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        default=None,
        related_name="viajes_modificados",
    )
    id_estado = models.ForeignKey(Estado, on_delete=models.CASCADE)  # Obligatorio
    id_ruta = models.ForeignKey(Ruta, on_delete=models.CASCADE)  # Obligatorio
    id_vehiculo = models.ForeignKey(
        Vehiculo,
        on_delete=models.CASCADE,
        db_column="id_vehiculo",
        null=True,
        blank=True,
    )
    id_conductor = models.ForeignKey(
        Conductor,  # Cambiado a Conductor
        on_delete=models.CASCADE,
        db_column="id_conductor",
        null=True,
        blank=True,
    )
    punto_partida = models.CharField(max_length=255, null=True, blank=True)
    punto_destino = models.CharField(max_length=255, null=True, blank=True)
    numero_pasajeros = models.IntegerField(
        validators=[validar_numero_pasajeros], null=True, blank=True
    )
    kilometros = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        validators=[validar_valor_no_negativo],
        null=True,
        blank=True,
    )
    valor_estimado = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[validar_valor_no_negativo],
        null=True,
        blank=True,
    )
    estado_inicio_real = models.TimeField(null=True, blank=True)
    estado_fin_real = models.TimeField(null=True, blank=True)
    motivo_cancelacion = models.CharField(max_length=255, null=True, blank=True)
    observaciones = models.TextField(null=True, blank=True)
    id_viaje_anterior = models.BigIntegerField(null=True, blank=True)
    tarifa_base = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[validar_valor_no_negativo],
        null=True,
        blank=True,
    )
    peajes = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[validar_valor_no_negativo],
        null=True,
        blank=True,
    )
    tarifa_total = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[validar_valor_no_negativo],
        null=True,
        blank=True,
    )
    confirmado_por_conductor = models.BooleanField(default=False)
    tipo_viaje = models.ForeignKey(
        TipoViaje, on_delete=models.CASCADE, null=True, blank=True
    )
    tiempo_estimado = models.CharField(
        max_length=50,  # Longitud suficiente para textos como "80 minutos"
        null=True,
        blank=True,
    )

    def save(self, *args, **kwargs):
        usuario_modificador = kwargs.pop("usuario_modificador", None)
        if usuario_modificador:
            print(f"Guardando usuario modificador con ID: {usuario_modificador.id}")
            self.usuario_modificador = usuario_modificador  # Asignación directa
        else:
            print("No se proporcionó usuario modificador.")
        super(Viaje, self).save(*args, **kwargs)

    def __str__(self):
        return self.codigo_viaje


def clean(self):
    super().clean()

    # Convertir la hora actual a la zona horaria de Chile
    chile_tz = pytz.timezone("America/Santiago")
    hora_actual_chile = now().astimezone(chile_tz)

    # Validación: la hora de salida no puede ser en el pasado si la fecha es hoy
    if self.fecha_salida and self.hora_salida:
        fecha_hora_salida = datetime.combine(self.fecha_salida, self.hora_salida)
        fecha_hora_salida = chile_tz.localize(fecha_hora_salida)

        if fecha_hora_salida < hora_actual_chile:
            raise ValidationError(
                "La hora de salida no puede ser en el pasado si el viaje es hoy (hora de Chile)."
            )

    # Validación: la hora de fin real debe ser después de la hora de inicio real
    if (
        self.estado_fin_real
        and self.estado_inicio_real
        and self.estado_fin_real < self.estado_inicio_real
    ):
        raise ValidationError("La hora de fin debe ser posterior a la hora de inicio.")

    # Validación: la fecha de llegada no puede ser anterior a la fecha de salida
    if (
        self.fecha_llegada
        and self.fecha_salida
        and self.fecha_llegada < self.fecha_salida
    ):
        raise ValidationError(
            "La fecha de llegada no puede ser anterior a la fecha de salida."
        )

    # Validación: la hora de llegada no puede ser anterior o igual a la hora de salida si están en el mismo día
    if (
        self.fecha_llegada == self.fecha_salida
        and self.hora_llegada
        and self.hora_salida
        and self.hora_llegada <= self.hora_salida
    ):
        raise ValidationError(
            "La hora de llegada no puede ser anterior o igual a la hora de salida."
        )


# Modelo RutaViaje
class RutaViaje(models.Model):
    id_viaje = models.ForeignKey(
        Viaje, on_delete=models.CASCADE, related_name="ruta_viaje"
    )
    rut_colaborador = models.ForeignKey(
        Colaborador,
        on_delete=models.CASCADE,
        related_name="ruta_viaje",
        db_column="rut_colaborador",
        null=True,
        blank=True,
    )
    latitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_latitud]
    )
    longitud = models.DecimalField(
        max_digits=25, decimal_places=15, validators=[validar_longitud]
    )
    orden = models.IntegerField(validators=[validar_orden])
    id_direccion = models.IntegerField(null=True, blank=True)
    hora_estimada_recogida = models.TimeField(null=True, blank=True)
    hora_estimada_llegada = models.TimeField(null=True, blank=True)
    hora_real_recogida = models.TimeField(null=True, blank=True)
    hora_real_llegada = models.TimeField(null=True, blank=True)

    def __str__(self):
        return f"Punto {self.orden} del viaje {self.id_viaje.codigo_viaje} para {self.rut_colaborador.rut_colaborador}"

    def clean(self):
        super().clean()
        if self.latitud == 0 and self.longitud == 0:
            raise ValidationError(
                "La latitud y la longitud no pueden ser ambas 0, ya que no representan una ubicación válida."
            )


class ViajeColaborador(models.Model):
    rut_colaborador = models.CharField(max_length=255)
    id_viaje = models.ForeignKey(
        "Viaje", on_delete=models.CASCADE, db_column="id_viaje"
    )
    hora_asignacion = models.DateTimeField()
    id_estado = models.ForeignKey(
        "Estado", on_delete=models.CASCADE, db_column="id_estado"
    )
    qr_escaneado = models.BooleanField(
        default=False
    )  # Indica si el QR fue escaneado o no
    qr_generado = models.BooleanField(
        default=False
    )  # Indica si el QR ha sido generado o no

    class Meta:
        unique_together = (("rut_colaborador", "id_viaje"),)


class LogEscaneoQR(models.Model):
    conductor = models.ForeignKey(
        Conductor, on_delete=models.CASCADE
    )  # Taxista que escanea el QR
    colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE
    )  # Colaborador del QR
    viaje = models.ForeignKey(Viaje, on_delete=models.CASCADE)  # Viaje asociado
    fecha_hora_escaneo = models.DateTimeField(
        auto_now_add=True
    )  # Momento en que se escaneó el QR
    resultado = models.CharField(
        max_length=50
    )  # Resultado del escaneo (ej. 'Asistencia confirmada', 'Colaborador no asignado')

    def __str__(self):
        return f"Escaneo por {self.conductor} de {self.colaborador} para viaje {self.viaje} el {self.fecha_hora_escaneo}"


class CalificacionComentario(models.Model):
    calificacion = models.IntegerField(
        choices=[(i, str(i)) for i in range(1, 6)], default=1  # Valores de 1 a 5
    )
    comentario = models.TextField(null=True, blank=True)  # Comentario opcional
    colaborador = models.ForeignKey(Colaborador, on_delete=models.CASCADE)
    viaje = models.ForeignKey(Viaje, on_delete=models.CASCADE)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = (
            "colaborador",
            "viaje",
        )  # Un colaborador puede calificar solo una vez por viaje

    def __str__(self):
        return f"Calificación de {self.colaborador} para el viaje {self.viaje.codigo_viaje}: {self.calificacion}"


class IncidenciaViaje(models.Model):
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_ultima_modificacion = models.DateTimeField(null=True, blank=True)
    rut_colaborador = models.ForeignKey(
        Colaborador,
        on_delete=models.CASCADE,
        related_name="incidencias_viajes_reportadas",
    )
    comentario = models.TextField()
    id_estado = models.ForeignKey(
        Estado,
        on_delete=models.SET_NULL,
        null=True,
        limit_choices_to={"entidad": "Incidencia"},
        related_name="incidencias_viajes",
    )
    id_viaje = models.ForeignKey(
        Viaje, on_delete=models.CASCADE, related_name="incidencias"
    )

    class Meta:
        # Elimina la restricción de unicidad
        # unique_together = ("rut_colaborador", "id_viaje")
        pass

    def __str__(self):
        return f"Incidencia en {self.id_viaje} - {self.id_estado.nombre_estado if self.id_estado else 'Estado no asignado'}"


class LogIncidenciaViaje(models.Model):
    fecha_comentario = models.DateTimeField(auto_now_add=True)
    comentario = models.TextField()
    rut_colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="log_incidencias_viaje"
    )
    id_estado = models.ForeignKey(
        Estado,
        on_delete=models.SET_NULL,
        null=True,
        limit_choices_to={"entidad": "Incidencia"},
        related_name="log_incidencias_viaje",
    )
    id_incidencia = models.ForeignKey(
        IncidenciaViaje, on_delete=models.CASCADE, related_name="log_incidencias"
    )

    def save(self, *args, **kwargs):
        # Actualizar el estado y la fecha de última modificación en IncidenciaViaje
        self.id_incidencia.id_estado = self.id_estado
        self.id_incidencia.fecha_ultima_modificacion = timezone.now()
        self.id_incidencia.save()  # Guarda la incidencia con los cambios de estado y fecha

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Log de Incidencia {self.id} para Incidencia {self.id_incidencia.id}"
