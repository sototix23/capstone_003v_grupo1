from django.core.management.base import BaseCommand
from viajes.tasks import finalizar_viajes_en_curso  # Importar la función


class Command(BaseCommand):
    help = (
        "Finaliza los viajes en curso que han pasado más de 24 horas desde su inicio."
    )

    def handle(self, *args, **kwargs):
        """
        Ejecuta la tarea y muestra mensajes en la consola.
        """
        self.stdout.write("Ejecutando tarea para finalizar viajes en curso...")
        resultado = finalizar_viajes_en_curso()
        if "error" in resultado:
            self.stderr.write(f"Error: {resultado['error']}")
        else:
            self.stdout.write(
                f"{resultado['viajes_actualizados']} viajes actualizados."
            )
        self.stdout.write("Tarea completada.")
