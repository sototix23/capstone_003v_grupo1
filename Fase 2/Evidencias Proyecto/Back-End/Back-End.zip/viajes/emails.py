from datetime import time, datetime
from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from email.mime.image import MIMEImage
import os
import requests
from babel.dates import format_date  # Para formatear las fechas
from django.utils.timezone import localtime  # Para manejar zonas horarias locales


def generar_url_mapa(ruta):
    """
    Genera una URL para un mapa de Google que muestra la ruta usando las coordenadas de inicio y fin.
    """
    base_url = "https://www.google.com/maps/dir/?api=1"
    origin = f"{ruta.punto_inicial_latitud},{ruta.punto_inicial_longitud}"
    destination = f"{ruta.punto_final_latitud},{ruta.punto_final_longitud}"
    return f"{base_url}&origin={origin}&destination={destination}"


from babel.dates import format_date  # Para formatear fechas


def enviar_correo_viaje_ruta(ruta_viaje):
    """
    Enviar un correo al colaborador al asignar su ruta (dirección) en el viaje.
    """
    viaje = ruta_viaje.id_viaje
    colaborador = ruta_viaje.rut_colaborador
    conductor = viaje.id_conductor

    # Obtener el primer nombre y apellidos del colaborador
    primer_nombre = colaborador.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = colaborador.apellido_paterno
    apellido_materno = colaborador.apellido_materno

    # Obtener tipo de viaje
    tipo_viaje = viaje.tipo_viaje.descripcion if viaje.tipo_viaje else "No especificado"

    # Inicialización de valores predeterminados
    hora_recogida = "No especificada"
    etiqueta_hora_recogida = "Hora estimada de recogida"
    hora_llegada = "No especificada"
    etiqueta_hora_llegada = "Hora estimada de llegada"

    # Lógica para viajes de ida y vuelta
    if tipo_viaje == "Viaje de ida":  # De casa al destino
        if ruta_viaje.hora_estimada_recogida:
            hora_recogida = ruta_viaje.hora_estimada_recogida.strftime("%H:%M:%S")
        if ruta_viaje.hora_estimada_llegada:
            hora_llegada = ruta_viaje.hora_estimada_llegada.strftime("%H:%M:%S")
    elif tipo_viaje == "Viaje de vuelta":  # De destino a casa
        if ruta_viaje.hora_estimada_llegada:  # Hora de llegada estimada a casa
            hora_llegada = ruta_viaje.hora_estimada_llegada.strftime("%H:%M:%S")
            etiqueta_hora_llegada = "Hora estimada de llegada a casa"

        # Para la recogida, usamos la hora de salida del viaje
        if viaje.hora_salida:
            hora_recogida = viaje.hora_salida.strftime("%H:%M:%S")
            etiqueta_hora_recogida = "Hora de salida del viaje"

    # Formatear la fecha de salida con Babel
    fecha_salida_formateada = format_date(
        viaje.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    # Datos del conductor
    conductor_info = (
        f"{conductor.nombres} {conductor.apellido_paterno} {conductor.apellido_materno}"
        if conductor
        else "No asignado"
    )
    conductor_telefono = conductor.telefono if conductor else "No disponible"

    # Ruta local de la imagen de logo (si existe)
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Detalles del correo
    subject = "Detalles de su Asignación de Ruta"
    text_content = (
        f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, "
        f"se ha asignado su ruta al viaje."
    )
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #28a745;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Detalles de su Asignación de Ruta</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Se le ha asignado una ruta en el viaje con los siguientes detalles:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Código del Viaje:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.codigo_viaje}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Tipo de Viaje:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{tipo_viaje}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>{etiqueta_hora_recogida}:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{hora_recogida}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>{etiqueta_hora_llegada}:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{hora_llegada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Conductor:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{conductor_info}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Teléfono del Conductor:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{conductor_telefono}</td>
                    </tr>
                </table>
                
                <p style="margin-top: 20px; text-align: center;">Gracias por su comprensión.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear el mensaje
    msg = EmailMultiAlternatives(
        subject, text_content, settings.EMAIL_HOST_USER, [colaborador.email]
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen de logo si existe
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            msg_image = MIMEImage(f.read())
            msg_image.add_header("Content-ID", "<logo_image>")
            msg.attach(msg_image)

    # Enviar el correo
    msg.send()


def enviar_correo_cancelacion_viaje(colaborador, viaje):
    """
    Envía un correo al colaborador notificándole que ha sido eliminado de un viaje.
    """
    conductor = viaje.id_conductor
    ruta = viaje.id_ruta

    # Obtener el primer nombre y apellidos del colaborador
    primer_nombre = colaborador.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = colaborador.apellido_paterno
    apellido_materno = colaborador.apellido_materno

    # Formatear la fecha de salida con Babel
    fecha_salida_formateada = format_date(
        viaje.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    # Detalles del correo
    subject = "Cancelación de su Asignación de Viaje"
    text_content = (
        f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, lamentamos informarle que ha sido "
        f"eliminado de la asignación al viaje {viaje.codigo_viaje}."
    )

    # Ruta local de la imagen de logo (si existe)
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Contenido HTML para el correo
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #dc3545;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Cancelación de Asignación de Viaje</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Lamentamos informarle que su asignación al viaje ha sido cancelada. A continuación, los detalles del viaje cancelado:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Código del Viaje:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.codigo_viaje}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.hora_salida.strftime('%H:%M:%S')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Ruta:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{ruta.descripcion_ruta}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Conductor:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{conductor.nombres} {conductor.apellido_paterno}</td>
                    </tr>
                </table>
                
                <p>Por motivos de organización, ha sido necesario cancelar su participación en este viaje. Sin embargo, estamos trabajando para asignarle un nuevo viaje. Recibirá una notificación por correo electrónico con los detalles de su próxima asignación.</p>
                
                <p style="margin-top: 20px; text-align: center;">Gracias por su comprensión.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear el mensaje
    msg = EmailMultiAlternatives(
        subject, text_content, settings.EMAIL_HOST_USER, [colaborador.email]
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen de logo si existe
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            msg_image = MIMEImage(f.read())
            msg_image.add_header("Content-ID", "<logo_image>")
            msg.attach(msg_image)

    # Enviar el correo
    msg.send()


def enviar_correo_cancelacion_viaje_completo(colaborador, viaje, motivo):
    """
    Envía un correo al colaborador notificándole que el viaje completo ha sido cancelado.
    """
    ruta = viaje.id_ruta
    vehiculo = viaje.id_vehiculo
    conductor = viaje.id_conductor

    # Obtener el primer nombre y apellidos del colaborador
    primer_nombre = colaborador.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = colaborador.apellido_paterno
    apellido_materno = colaborador.apellido_materno

    # Formatear la fecha de salida con Babel
    fecha_salida_formateada = format_date(
        viaje.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    # Verificar conductor y vehículo
    conductor_info = (
        f"{conductor.nombres} {conductor.apellido_paterno} {conductor.apellido_materno}"
        if conductor
        else "Conductor no asignado"
    )
    vehiculo_info = (
        f"{vehiculo.marca} {vehiculo.modelo} - Matrícula: {vehiculo.patente}"
        if vehiculo
        else "Vehículo no asignado"
    )
    ruta_info = ruta.descripcion_ruta if ruta else "Ruta no asignada"

    # Asunto y contenido de texto
    subject = "Cancelación de Viaje Completo"
    text_content = (
        f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, lamentamos informarle que el viaje "
        f"{viaje.codigo_viaje} ha sido cancelado por el siguiente motivo: {motivo}."
    )

    # Ruta local de la imagen de logo (si existe)
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Contenido HTML del correo
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #dc3545;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Cancelación de Viaje Completo</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Lamentamos informarle que el viaje con el código <strong>{viaje.codigo_viaje}</strong> ha sido cancelado. A continuación, los detalles del viaje cancelado:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Destino:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{ruta_info}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.hora_salida.strftime('%H:%M:%S')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Conductor:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{conductor_info}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Vehículo:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{vehiculo_info}</td>
                    </tr>
                </table>
                
                <p><strong>Motivo de cancelación:</strong> {motivo}</p>
                
                <p style="margin-top: 20px; text-align: center;">Gracias por su comprensión.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear y enviar el correo
    msg = EmailMultiAlternatives(
        subject,
        text_content,
        settings.EMAIL_HOST_USER,
        [colaborador.email if colaborador else "correo@predeterminado.com"],
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen de logo si existe
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            msg_image = MIMEImage(f.read())
            msg_image.add_header("Content-ID", "<logo_image>")
            msg.attach(msg_image)

    msg.send()


def enviar_correo_cancelacion_conductor(conductor, viaje, motivo):
    """
    Envía un correo al conductor notificándole que el viaje ha sido cancelado.
    """
    ruta = viaje.id_ruta

    # Obtener el primer nombre y apellidos del conductor
    primer_nombre = conductor.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = conductor.apellido_paterno
    apellido_materno = conductor.apellido_materno

    # Formatear la fecha de salida con Babel
    fecha_salida_formateada = format_date(
        viaje.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    # Asunto y contenido de texto
    subject = "Cancelación de Viaje Asignado como Conductor"
    text_content = (
        f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, lamentamos informarle que el viaje "
        f"{viaje.codigo_viaje} que tenía asignado ha sido cancelado por el siguiente motivo: {motivo}."
    )

    # Ruta local de la imagen de logo (si existe)
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Contenido HTML del correo
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #dc3545;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Cancelación de Viaje Asignado</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Le informamos que el viaje con el código <strong>{viaje.codigo_viaje}</strong> ha sido cancelado. A continuación, los detalles del viaje cancelado:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Destino:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{ruta.descripcion_ruta}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.hora_salida.strftime('%H:%M:%S')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Motivo de Cancelación:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{motivo}</td>
                    </tr>
                </table>
                
                <p style="margin-top: 20px; text-align: center;">Gracias por su comprensión.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear y enviar el correo
    msg = EmailMultiAlternatives(
        subject,
        text_content,
        settings.EMAIL_HOST_USER,
        [conductor.email],
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen de logo si existe
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            msg_image = MIMEImage(f.read())
            msg_image.add_header("Content-ID", "<logo_image>")
            msg.attach(msg_image)

    msg.send()


def enviar_correo_asignacion_conductor(conductor, viaje):
    """
    Enviar un correo al conductor con los detalles del viaje asignado, con diseño HTML consistente.
    """
    # Ruta local de la imagen de logo (si existe)
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Obtener el primer nombre y apellidos del conductor
    primer_nombre = conductor.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = conductor.apellido_paterno
    apellido_materno = conductor.apellido_materno

    # Formatear la fecha de salida con Babel
    fecha_salida_formateada = format_date(
        viaje.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    # Verificar datos de la ruta
    ruta_info = viaje.id_ruta.descripcion_ruta if viaje.id_ruta else "No especificada"

    # Título y contenido del correo
    subject = "Asignación de Viaje como Conductor"
    text_content = f"""
    Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno},

    Ha sido asignado/a al siguiente viaje:
    - Código del viaje: {viaje.codigo_viaje}
    - Fecha de salida: {fecha_salida_formateada}
    - Hora de salida: {viaje.hora_salida.strftime('%H:%M:%S')}
    - Ruta: {ruta_info}

    Por favor, revise los detalles en el sistema.

    Saludos cordiales,
    Equipo de Gestión de Transporte
    VeteranBytes
    """
    # Contenido HTML para el diseño
    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Asignación de viaje</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; margin: auto; background: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 6px rgba(0,0,0,0.1); border-top: 8px solid #28a745;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Asignación de Viaje</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Ha sido asignado/a al siguiente viaje:</p>
                <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Código del Viaje:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.codigo_viaje}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{viaje.hora_salida.strftime('%H:%M:%S')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Ruta:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{ruta_info}</td>
                    </tr>
                </table>
                
                <p style="margin-top: 20px; text-align: center;">Por favor, revise los detalles en el sistema.</p>
                <p style="text-align: center; font-weight: bold;">Saludos cordiales,<br>Equipo de Gestión de Transporte<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear el mensaje de correo
    msg = EmailMultiAlternatives(
        subject,
        text_content,
        settings.EMAIL_HOST_USER,
        [conductor.email],
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen de logo si existe
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            msg_image = MIMEImage(f.read())
            msg_image.add_header("Content-ID", "<logo_image>")
            msg.attach(msg_image)

    # Enviar el correo
    msg.send()
