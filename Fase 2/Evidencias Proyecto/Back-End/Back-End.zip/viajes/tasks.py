import logging
from datetime import timedelta
from django.utils.timezone import now
from django.db import transaction
from .models import Viaje

# Configuración de logs
logger = logging.getLogger("viajes")  # Puedes usar cualquier nombre para tu logger


@transaction.atomic
def finalizar_viajes_en_curso():
    """
    Finaliza los viajes en curso (estado id=2) que han pasado más de 24 horas desde su inicio.
    Cambia su estado a 'Completado' (estado id=3).
    """
    logger.info("Iniciando la tarea para finalizar viajes en curso...")

    # IDs de los estados
    ESTADO_EN_CURSO = 2
    ESTADO_COMPLETADO = 3

    # Calcular el límite de tiempo
    limite_tiempo = now() - timedelta(hours=24)

    # Filtrar y actualizar los viajes en curso
    viajes_actualizados = Viaje.objects.filter(
        id_estado_id=ESTADO_EN_CURSO,  # Estado "En Curso"
        fecha_salida__lte=limite_tiempo.date(),
        hora_salida__lte=limite_tiempo.time(),
    ).update(
        id_estado_id=ESTADO_COMPLETADO
    )  # Estado "Completado"

    logger.info(f"{viajes_actualizados} viajes actualizados a estado 'Completado'.")
    return {"viajes_actualizados": viajes_actualizados}
