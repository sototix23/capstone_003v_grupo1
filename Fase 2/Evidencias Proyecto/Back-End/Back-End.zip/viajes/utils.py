import qrcode
from io import BytesIO
import base64
import hashlib
from django.utils import timezone


def generar_codigo_qr(colaborador, viaje):
    """
    Genera un código QR dinámico con la información del colaborador y del viaje.
    Devuelve el QR en formato base64, junto con el token y el timestamp.
    """
    # Crear el timestamp actual
    qr_timestamp = int(timezone.now().timestamp())

    # Crear el token basado en el colaborador y el viaje
    qr_token = hashlib.sha256(
        f"{colaborador.rut_colaborador}-{viaje.id}-{qr_timestamp}".encode()
    ).hexdigest()

    print(f"Generado qr_token: {qr_token}, qr_timestamp: {qr_timestamp}")
    # Crear la URL o cadena con el token del QR y otra información relevante
    data = f"Token: {qr_token}, Timestamp: {qr_timestamp}"  # Incluye tanto el hash como el timestamp

    # Generar el código QR con la data anterior
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)

    # Convertir a imagen
    img = qr.make_image(fill="black", back_color="white")

    # Guardar la imagen en un buffer
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    qr_image_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")

    return {
        "qr_code": qr_image_base64,  # Código QR en base64
        "qr_token": qr_token,  # Token hash para comparación
        "qr_timestamp": qr_timestamp,
    }
