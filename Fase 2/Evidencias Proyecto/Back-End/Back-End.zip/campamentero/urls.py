from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import (
    HabitacionViewSet,
    AsignacionHabitacionViewSet,
    GenerarQRHabitacionView,
    ValidarQRHabitacionView,
    UbicacionViewSet,
    ComentarioCalidadHabitacionViewSet,
    IncidenciaHabitacionViewSet,
    LogIncidenciaHabitacionCreateView,
)

router = DefaultRouter()
router.register(r"habitaciones", HabitacionViewSet, basename="habitaciones")
router.register(
    r"asignacion-habitacion",
    AsignacionHabitacionViewSet,
    basename="asignacion-habitacion",
)
router.register(r"comentarios-calidad", ComentarioCalidadHabitacionViewSet)
router.register(r"ubicaciones", UbicacionViewSet, basename="ubicaciones")
router.register(
    r"incidencias-habitacion",
    IncidenciaHabitacionViewSet,
    basename="incidencias-habitacion",
)


urlpatterns = [
    path(
        "asignacion-habitacion/generar-qr/<int:id_asignacion>/<str:rut_colaborador>/<str:tipo>/",
        GenerarQRHabitacionView.as_view(),
        name="generar_qr_habitacion",
    ),
    path(
        "asignacion-habitacion/validar-qr/",
        ValidarQRHabitacionView.as_view(),
        name="validar_qr_habitacion",
    ),
    path(
        "log-incidencias/",
        LogIncidenciaHabitacionCreateView.as_view(),
        name="log_incidencias",
    ),
]

# Agregar las URLs del router a las urlpatterns
urlpatterns += router.urls
