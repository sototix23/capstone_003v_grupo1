from django.core.exceptions import ValidationError
from django.utils import timezone


# Validar que la fecha de ingreso no sea en el pasado
def validar_fecha_ingreso(value):
    if value < timezone.now().date():
        raise ValidationError("La fecha de ingreso no puede ser en el pasado.")


# Validar que la fecha de salida sea posterior a la fecha de ingreso
def validar_fecha_salida(value):
    if value < timezone.now().date():
        raise ValidationError(
            "La fecha de salida debe ser posterior a la fecha de ingreso."
        )
