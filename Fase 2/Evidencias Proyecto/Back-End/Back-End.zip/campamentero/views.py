from rest_framework import viewsets, status, permissions, generics
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
import hashlib

from .models import (
    Habitacion,
    AsignacionHabitacion,
    LogEscaneoQRHabitacion,
    Ubicacion,
    ComentarioCalidadHabitacion,
    IncidenciaHabitacion,
    LogIncidenciaHabitacion,
)
from colaboradores.models import Colaborador
from .serializers import (
    HabitacionSerializer,
    AsignacionHabitacionSerializer,
    ValidarQRHabitacionSerializer,
    UbicacionSerializer,
    InfoAsignacionSerializer,
    ComentarioCalidadHabitacionSerializer,
    IncidenciaHabitacionSerializer,
    LogIncidenciaHabitacionSerializer,
)
from .utils import generar_codigo_qr
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from viajes.models import Estado
from django.utils.timezone import make_aware
from datetime import datetime
from django.core.mail import send_mail
from django.conf import settings
from .emails import enviar_correo_asignacion, enviar_correo_cancelacion
from rest_framework.exceptions import ValidationError
from rest_framework.pagination import PageNumberPagination
import pytz


class UbicacionViewSet(viewsets.ModelViewSet):
    queryset = Ubicacion.objects.all()
    serializer_class = UbicacionSerializer
    permission_classes = [IsAuthenticated]


class HabitacionViewSet(viewsets.ModelViewSet):
    queryset = Habitacion.objects.all()
    serializer_class = HabitacionSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["get"], url_path="disponibilidad")
    def verificar_disponibilidad(self, request):
        """
        Verifica la disponibilidad de habitaciones en un rango de fechas.
        """
        fecha_ingreso = request.query_params.get("fecha_ingreso")
        fecha_salida = request.query_params.get("fecha_salida")

        # Validar que las fechas sean proporcionadas
        if not fecha_ingreso or not fecha_salida:
            return Response(
                {
                    "error": "Debes proporcionar las fechas 'fecha_ingreso' y 'fecha_salida'."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Convertir fechas en objetos datetime
        try:
            fecha_ingreso = timezone.datetime.strptime(fecha_ingreso, "%Y-%m-%d").date()
            fecha_salida = timezone.datetime.strptime(fecha_salida, "%Y-%m-%d").date()
        except ValueError:
            return Response(
                {"error": "Las fechas deben estar en el formato 'YYYY-MM-DD'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Validar que las fechas no sean en el pasado
        fecha_actual = timezone.now().date()
        if fecha_ingreso < fecha_actual:
            return Response(
                {"error": "La fecha de ingreso no puede ser en el pasado."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if fecha_salida <= fecha_ingreso:
            return Response(
                {
                    "error": "La fecha de salida debe ser posterior a la fecha de ingreso."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Filtrar habitaciones disponibles (sin reservas en las fechas especificadas)
        habitaciones_disponibles = Habitacion.objects.exclude(
            asignaciones__fecha_ingreso__lte=fecha_salida,
            asignaciones__fecha_salida__gte=fecha_ingreso,
            asignaciones__estado_reserva_id__in=[70],  # 70: Reservada
        )

        # Serializar y devolver las habitaciones disponibles
        serializer = self.get_serializer(habitaciones_disponibles, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class LargeResultsSetPagination(PageNumberPagination):
    page_size = 10


class AsignacionHabitacionViewSet(viewsets.ModelViewSet):
    queryset = AsignacionHabitacion.objects.all()
    serializer_class = AsignacionHabitacionSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = LargeResultsSetPagination

    # Método en la clase Habitacion para verificar disponibilidad
    def esta_disponible(self, fecha_ingreso, fecha_salida):
        # Excluir asignaciones en estado 'Cancelado' (estado_reserva_id=71)
        asignaciones = AsignacionHabitacion.objects.filter(
            id_habitacion=self,
            fecha_ingreso__lte=fecha_salida,
            fecha_salida__gte=fecha_ingreso,
        ).exclude(estado_reserva_id=71)

        # Retorna True si no existen asignaciones en esas fechas, lo que indica disponibilidad
        return not asignaciones.exists()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        habitacion_id = request.data.get("id_habitacion")
        rut_colaborador = request.data["rut_colaborador"]

        # Obtener la habitación usando su ID
        try:
            habitacion = Habitacion.objects.get(id=habitacion_id)
        except Habitacion.DoesNotExist:
            return Response(
                {"error": "La habitación no existe."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Validar que la habitación esté 'Habilitada' (ID 67)
        if habitacion.estado.id != 67:  # 67 es el ID de 'Habilitado'
            return Response(
                {
                    "error": f"La habitación está en estado '{habitacion.estado.nombre_estado}' y no puede ser reservada."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Validar disponibilidad de la habitación excluyendo asignaciones canceladas
        fecha_ingreso = request.data["fecha_ingreso"]
        fecha_salida = request.data["fecha_salida"]
        if (
            AsignacionHabitacion.objects.filter(
                id_habitacion=habitacion,
                fecha_ingreso__lte=fecha_salida,
                fecha_salida__gte=fecha_ingreso,
            )
            .exclude(estado_reserva_id=71)  # Excluir asignaciones en estado Cancelado
            .exists()
        ):
            return Response(
                {
                    "habitacion": habitacion.id,
                    "detail": "La habitación ya está reservada en el período especificado.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Validar que el colaborador no esté asignado en otro lugar en el mismo período, excluyendo asignaciones canceladas
        if (
            AsignacionHabitacion.objects.filter(
                rut_colaborador=rut_colaborador,
                fecha_ingreso__lte=fecha_salida,
                fecha_salida__gte=fecha_ingreso,
            )
            .exclude(estado_reserva_id=71)
            .exists()
        ):
            return Response(
                {
                    "colaborador": rut_colaborador,
                    "detail": "El colaborador ya tiene una asignación en este período.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Guardar la asignación con el estado de reserva 'No Disponible' (ID 70)
        asignacion = serializer.save(estado_reserva_id=70)  # No Disponible

        try:
            # Enviar correo de asignación
            enviar_correo_asignacion(asignacion)
        except Exception as e:
            return Response(
                {"error": f"No se pudo enviar el correo: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=["post"], url_path="crear-multiples")
    def crear_multiples(self, request):
        """
        Endpoint para asignar múltiples colaboradores a habitaciones.
        """
        data = request.data
        if not isinstance(data, list):
            return Response(
                {"error": "Los datos deben ser una lista de asignaciones."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        created_asignaciones = []
        errors = []

        for item in data:
            serializer = self.get_serializer(data=item)
            try:
                serializer.is_valid(raise_exception=True)
            except Exception as e:
                errors.append({"item": item, "error": str(e)})
                continue

            habitacion_id = item.get("id_habitacion")
            rut_colaborador = item["rut_colaborador"]

            try:
                habitacion = Habitacion.objects.get(id=habitacion_id)
            except Habitacion.DoesNotExist:
                errors.append({"item": item, "error": "La habitación no existe."})
                continue

            # Validar que la habitación esté 'Habilitada' (id=67)
            if habitacion.estado.id != 67:
                errors.append(
                    {
                        "item": item,
                        "error": f"La habitación está en estado '{habitacion.estado.nombre_estado}' y no puede ser reservada.",
                    }
                )
                continue

            # Validar que la habitación no esté ya reservada en el período
            if (
                AsignacionHabitacion.objects.filter(
                    id_habitacion=habitacion,
                    fecha_ingreso__lte=item["fecha_salida"],
                    fecha_salida__gte=item["fecha_ingreso"],
                )
                .exclude(estado_reserva_id=71)  # Excluir cancelaciones (ID 71)
                .exists()
            ):
                errors.append(
                    {
                        "item": item,
                        "error": "La habitación ya está reservada en el período especificado.",
                    }
                )
                continue

            # Validar que el colaborador no esté asignado en otro lugar en el mismo período
            if AsignacionHabitacion.objects.filter(
                rut_colaborador=rut_colaborador,
                fecha_ingreso__lte=item["fecha_salida"],
                fecha_salida__gte=item["fecha_ingreso"],
            ).exists():
                errors.append(
                    {
                        "item": item,
                        "error": "El colaborador ya tiene una asignación en este período.",
                    }
                )
                continue

            # Guardar la asignación con el estado de reserva 'No Disponible' (ID 70)
            try:
                asignacion = serializer.save(estado_reserva_id=70)  # No Disponible
                # Enviar correo de asignación
                enviar_correo_asignacion(asignacion)
                created_asignaciones.append(serializer.data)
            except Exception as e:
                errors.append(
                    {"item": item, "error": f"No se pudo enviar el correo: {str(e)}"}
                )

        if errors:
            return Response(
                {"created": created_asignaciones, "errors": errors},
                status=status.HTTP_207_MULTI_STATUS,
            )

        return Response(created_asignaciones, status=status.HTTP_201_CREATED)

    @action(
        detail=True,
        methods=["delete"],
        url_path="colaborador/(?P<rut_colaborador>[^/.]+)",
    )
    def eliminar_colaborador(self, request, pk=None, rut_colaborador=None):
        """
        Eliminar un colaborador de una habitación y cambiar su estado a 'Disponible'.
        """
        try:
            # Obtiene la asignación por ID
            asignacion = self.get_object()

            # Verifica que el RUT del colaborador coincida con la asignación
            if asignacion.rut_colaborador.rut != rut_colaborador:
                return Response(
                    {"error": "El RUT del colaborador no coincide con la asignación."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            habitacion = asignacion.id_habitacion  # La habitación asociada

            # Eliminar la asignación
            asignacion.delete()

            # Cambiar el estado de la habitación a 'Disponible'
            nuevo_estado = Estado.objects.get(id=67)  # 67 es el ID de 'Habilitado'
            habitacion.estado = nuevo_estado
            habitacion.save()

            return Response(
                {"detail": "Colaborador eliminado y habitación habilitada."},
                status=status.HTTP_204_NO_CONTENT,
            )
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {"error": "Asignación no encontrada."}, status=status.HTTP_404_NOT_FOUND
            )
        except Estado.DoesNotExist:
            return Response(
                {"error": "El estado de 'Habilitado' no existe en la base de datos."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @action(detail=True, methods=["get"], url_path="info-asignacion")
    def info_asignacion(self, request, pk=None):
        """
        Devuelve toda la información de la asignación, incluyendo datos de la habitación y del colaborador.
        """
        try:
            asignacion = self.get_object()
            serializer = InfoAsignacionSerializer(asignacion)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {"error": "Asignación no encontrada."}, status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=False, methods=["get"], url_path="lista-info-asignacion")
    def lista_info_asignaciones(self, request):
        habitacion_id = request.query_params.get("habitacion_id")
        colaborador_rut = request.query_params.get("colaborador_rut")
        asignacion_id = request.query_params.get(
            "id_asignacion"
        )  # Nuevo filtro por id de asignación

        # Aplicar los filtros antes de limitar a 500 resultados
        queryset = self.queryset

        if habitacion_id:
            queryset = queryset.filter(id_habitacion__id=habitacion_id)
        if colaborador_rut:
            queryset = queryset.filter(rut_colaborador__rut_colaborador=colaborador_rut)
        if asignacion_id:
            queryset = queryset.filter(id=asignacion_id)  # Filtrar por id de asignación

        # Ahora limitar a las últimas 500 asignaciones
        queryset = queryset.order_by("-id")[:500]

        # Paginación
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = InfoAsignacionSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        # Serialización de los resultados
        serializer = InfoAsignacionSerializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=["post"], url_path="cancelar-reserva")
    def cancelar_reserva(self, request, pk=None):
        """
        Cancelar una reserva de habitación y notificar al colaborador.
        """
        try:
            asignacion = self.get_object()

            # Verificar si la asignación ya está cancelada
            if (
                asignacion.estado_reserva_id == 71
            ):  # Suponiendo que 71 es el ID para 'Cancelado'
                return Response(
                    {"detail": "La reserva ya está cancelada."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Cambiar el estado de la reserva a 'Cancelado'
            asignacion.estado_reserva_id = 71  # ID de 'Cancelado'
            asignacion.save()

            # Cambiar el estado de la habitación a 'Disponible'
            habitacion = asignacion.id_habitacion
            habitacion.estado_id = 67  # ID de 'Habilitado'
            habitacion.save()

            # Enviar correo de notificación de cancelación al colaborador
            enviar_correo_cancelacion(asignacion)

            return Response(
                {
                    "detail": "Reserva cancelada y habitación marcada como disponible. Se ha notificado al colaborador."
                },
                status=status.HTTP_200_OK,
            )

        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {"detail": "Asignación de habitación no encontrada."},
                status=status.HTTP_404_NOT_FOUND,
            )

    @action(
        detail=False,
        methods=["get"],
        url_path="historial-habitaciones/(?P<rut_colaborador>[^/.]+)",
    )
    def historial_habitaciones(self, request, rut_colaborador=None):
        """
        Endpoint para obtener el historial de todas las asignaciones de habitaciones del colaborador por su RUT.
        """
        # Convertir el RUT a minúsculas para la comparación
        rut_colaborador = rut_colaborador.lower()

        # Filtrar todas las asignaciones del colaborador con el rut especificado
        historial = AsignacionHabitacion.objects.filter(
            rut_colaborador__rut_colaborador__iexact=rut_colaborador
        ).order_by("-fecha_ingreso")

        if not historial.exists():
            return Response(
                {"detail": "No se encontraron asignaciones para el RUT especificado."},
                status=status.HTTP_200_OK,
            )

        serializer = InfoAsignacionSerializer(historial, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ComentarioCalidadHabitacionViewSet(viewsets.ModelViewSet):
    queryset = ComentarioCalidadHabitacion.objects.all()
    serializer_class = ComentarioCalidadHabitacionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        rut_colaborador = request.data.get("colaborador")
        asignacion_habitacion_id = request.data.get("asignacion_habitacion")

        print("Request User RUT:", request.user.rut)
        print("Colaborador en la solicitud:", rut_colaborador)

        if request.user.rut != rut_colaborador:
            return Response(
                {
                    "detail": "Acceso denegado. Solo el colaborador asignado puede calificar."
                },
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            asignacion_habitacion = AsignacionHabitacion.objects.get(
                id=asignacion_habitacion_id,
                rut_colaborador__rut_colaborador=rut_colaborador,
            )
            print("Asignación encontrada:", asignacion_habitacion)
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {
                    "detail": "Asignación de habitación no encontrada o no pertenece al colaborador."
                },
                status=status.HTTP_404_NOT_FOUND,
            )

        # Verificar que la fecha real de salida esté establecida
        if not asignacion_habitacion.fecha_real_salida:
            return Response(
                {
                    "detail": "No se puede comentar hasta que el colaborador haya salido de la habitación."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        if ComentarioCalidadHabitacion.objects.filter(
            colaborador__rut_colaborador=rut_colaborador,
            asignacion_habitacion=asignacion_habitacion,
        ).exists():
            return Response(
                {"detail": "Ya existe una calificación para esta asignación."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().create(request, *args, **kwargs)


class GenerarQRHabitacionView(APIView):
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                "id_asignacion",
                openapi.IN_PATH,
                description="ID de la asignación de habitación",
                type=openapi.TYPE_INTEGER,
            ),
            openapi.Parameter(
                "rut_colaborador",
                openapi.IN_PATH,
                description="RUT del colaborador",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "tipo",
                openapi.IN_PATH,
                description="Tipo de QR ('entrada' o 'salida')",
                type=openapi.TYPE_STRING,
            ),
        ],
        responses={
            200: openapi.Response(
                description="Código QR generado con éxito",
                examples={
                    "application/json": {
                        "qr_code": "base64_encoded_qr_image",
                        "qr_token": "generated_token",
                        "qr_timestamp": 1697040304,
                        "tipo": "entrada",
                    }
                },
            ),
            403: "Acceso denegado. Solo el colaborador asignado puede generar el QR.",
            404: "Colaborador o asignación de habitación no encontrada.",
        },
    )
    def get(self, request, id_asignacion, rut_colaborador, tipo):
        """
        Genera un código QR para la entrada o salida de la asignación de habitación.
        """
        if tipo not in ["entrada", "salida"]:
            return Response(
                {"error": "Tipo de QR no válido. Debe ser 'entrada' o 'salida'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            # Verificar que el usuario autenticado sea el colaborador solicitado
            if request.user.rut != rut_colaborador:
                return Response(
                    {
                        "error": "Acceso denegado. Solo el colaborador asignado puede generar el QR."
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Obtener colaborador y asignación de habitación
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            asignacion = AsignacionHabitacion.objects.get(
                id=id_asignacion, rut_colaborador=colaborador
            )

            # Validación de Sesión Activa del Usuario
            if colaborador.situacion_laboral != "Activo":
                return Response(
                    {"error": "El colaborador no está en estado activo."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Validación del Estado de la Habitación
            if asignacion.id_habitacion.estado.id != 67:  # 67 es el ID de 'Habilitado'
                return Response(
                    {"error": "La habitación asignada no está habilitada."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Verificación de la Finalización del Proceso Anterior
            if tipo == "entrada" and asignacion.fecha_real_ingreso:
                return Response(
                    {"error": "La entrada ya ha sido confirmada."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            if tipo == "salida":
                if not asignacion.fecha_real_ingreso:
                    return Response(
                        {
                            "error": "No se puede generar QR de salida antes de confirmar la entrada."
                        },
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                if asignacion.fecha_real_salida:
                    return Response(
                        {"error": "La salida ya ha sido confirmada."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )

            # Generar el código QR
            qr_data = generar_codigo_qr(colaborador, asignacion, tipo)
            qr_code_base64 = qr_data.get("qr_code")
            qr_token = qr_data.get("qr_token")
            qr_timestamp = qr_data.get("qr_timestamp")

            return Response(
                {
                    "qr_code": qr_code_base64,
                    "qr_token": qr_token,
                    "qr_timestamp": qr_timestamp,
                    "tipo": tipo,
                },
                status=status.HTTP_200_OK,
            )

        except Colaborador.DoesNotExist:
            return Response(
                {"error": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {"error": "Asignación de habitación no encontrada."},
                status=status.HTTP_404_NOT_FOUND,
            )


class ValidarQRHabitacionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    @swagger_auto_schema(
        manual_parameters=[
            openapi.Parameter(
                "id_asignacion",
                openapi.IN_PATH,
                description="ID de la asignación de habitación",
                type=openapi.TYPE_INTEGER,
            ),
            openapi.Parameter(
                "rut_colaborador",
                openapi.IN_PATH,
                description="RUT del colaborador",
                type=openapi.TYPE_STRING,
            ),
            openapi.Parameter(
                "tipo",
                openapi.IN_PATH,
                description="Tipo de QR ('entrada' o 'salida')",
                type=openapi.TYPE_STRING,
            ),
        ],
        responses={
            200: openapi.Response(
                description="Código QR validado con éxito",
                examples={
                    "application/json": {
                        "status": "Asistencia de ingreso confirmada",
                    }
                },
            ),
            403: "Acceso denegado. Debes pertenecer al grupo 'Campamentero' para realizar esta acción.",
            404: "Colaborador o asignación de habitación no encontrada.",
        },
    )
    def post(self, request):
        serializer = ValidarQRHabitacionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        rut_colaborador = serializer.validated_data["rut_colaborador"]
        id_asignacion = serializer.validated_data["id_asignacion"]
        qr_token = serializer.validated_data["qr_token"]

        if not request.user.groups.filter(name="Campamentero").exists():
            return Response(
                {
                    "error": "Acceso denegado. Debes pertenecer al grupo 'Campamentero' para realizar esta acción."
                },
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            encargado = Colaborador.objects.get(rut_colaborador=request.user.rut)
            colaborador = Colaborador.objects.get(rut_colaborador=rut_colaborador)
            asignacion = AsignacionHabitacion.objects.get(
                id=id_asignacion, rut_colaborador=colaborador
            )

            # Validar el token del QR para entrada o salida
            for tipo in ["entrada", "salida"]:
                valid_token = hashlib.sha256(
                    f"{rut_colaborador}-{id_asignacion}-{tipo}".encode()
                ).hexdigest()
                if qr_token == valid_token:
                    # Configuración de la zona horaria de Santiago de Chile
                    santiago_tz = pytz.timezone("America/Santiago")
                    # Obtiene la hora actual en Santiago de Chile
                    current_time = timezone.now().astimezone(santiago_tz)

                    if tipo == "entrada":
                        if current_time.date() < asignacion.fecha_ingreso:
                            return Response(
                                {
                                    "error": "El ingreso no puede registrarse antes de la fecha asignada."
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        if asignacion.hora_real_ingreso:
                            return Response(
                                {
                                    "error": "Este código QR ya ha sido escaneado para ingreso."
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )
                        asignacion.fecha_real_ingreso = current_time.date()
                        asignacion.hora_real_ingreso = current_time
                        mensaje = "Asistencia de ingreso confirmada"
                    else:  # Validación para "salida"
                        if not asignacion.hora_real_ingreso:
                            return Response(
                                {
                                    "error": "No se puede registrar la salida antes de haber registrado el ingreso."
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )

                        if asignacion.hora_real_salida:
                            return Response(
                                {
                                    "error": "Este código QR ya ha sido escaneado para salida."
                                },
                                status=status.HTTP_400_BAD_REQUEST,
                            )
                        asignacion.fecha_real_salida = current_time.date()
                        asignacion.hora_real_salida = current_time

                        # Actualizar el estado de la reserva a "Disponible"
                        asignacion.estado_reserva_id = (
                            69  # Suponiendo que 69 es el ID de 'Disponible'
                        )

                        mensaje = "Asistencia de salida confirmada"

                    asignacion.save()

                    # Registrar el escaneo sin geolocalización
                    LogEscaneoQRHabitacion.objects.create(
                        encargado=encargado,
                        colaborador=colaborador,
                        asignacion_habitacion=asignacion,
                        resultado="confirmado",
                        ip_address=None,  # Asignar None si no se requiere
                        ciudad=None,  # Asignar None si no se requiere
                        pais=None,  # Asignar None si no se requiere
                        latitud=None,  # Asignar None si no se requiere
                        longitud=None,  # Asignar None si no se requiere
                        tipo=tipo,  # Almacenamos el tipo de QR
                    )

                    return Response(
                        {"status": mensaje},
                        status=status.HTTP_200_OK,
                    )

            return Response(
                {
                    "error": "El código QR no coincide con el colaborador o la asignación."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except Colaborador.DoesNotExist:
            return Response(
                {"error": "Colaborador no encontrado."},
                status=status.HTTP_404_NOT_FOUND,
            )
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {"error": "Asignación de habitación no encontrada."},
                status=status.HTTP_404_NOT_FOUND,
            )


class IncidenciaHabitacionViewSet(viewsets.ModelViewSet):
    queryset = IncidenciaHabitacion.objects.all()
    serializer_class = IncidenciaHabitacionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        id_estado = self.request.query_params.get("id_estado")

        # Aplicar filtro por id_estado si está presente en los parámetros de la solicitud
        if id_estado:
            queryset = queryset.filter(id_estado__id=id_estado)

        return queryset

    def create(self, request, *args, **kwargs):
        rut_colaborador = request.data.get("rut_colaborador")
        asignacion_habitacion_id = request.data.get("id_asignacion_habitacion")

        # Validar que el colaborador autenticado sea el mismo en la solicitud
        if request.user.rut != rut_colaborador:
            return Response(
                {
                    "detail": "Acceso denegado. Solo el colaborador asignado puede reportar la incidencia."
                },
                status=status.HTTP_403_FORBIDDEN,
            )

        try:
            asignacion_habitacion = AsignacionHabitacion.objects.get(
                id=asignacion_habitacion_id,
                rut_colaborador__rut_colaborador=rut_colaborador,
            )
        except AsignacionHabitacion.DoesNotExist:
            return Response(
                {
                    "detail": "Asignación de habitación no encontrada o no pertenece al colaborador."
                },
                status=status.HTTP_404_NOT_FOUND,
            )

        # Eliminar la verificación de duplicidad para permitir múltiples incidencias
        # if IncidenciaHabitacion.objects.filter(
        #     rut_colaborador__rut_colaborador=rut_colaborador,
        #     id_asignacion_habitacion=asignacion_habitacion,
        # ).exists():
        #     return Response(
        #         {"detail": "Ya existe una incidencia para esta asignación."},
        #         status=status.HTTP_400_BAD_REQUEST,
        #     )

        return super().create(request, *args, **kwargs)


class LogIncidenciaHabitacionCreateView(generics.ListCreateAPIView):
    serializer_class = LogIncidenciaHabitacionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        id_incidencia = self.request.query_params.get("id_incidencia")

        if id_incidencia:
            # Filtra los logs por el id de la incidencia especificada
            return LogIncidenciaHabitacion.objects.filter(id_incidencia=id_incidencia)

        # Si no se especifica `id_incidencia`, filtra los logs según el colaborador autenticado
        return LogIncidenciaHabitacion.objects.filter(
            id_incidencia__rut_colaborador__rut_colaborador=self.request.user.rut
        )

    def perform_create(self, serializer):
        # Obtener el colaborador autenticado
        colaborador = Colaborador.objects.get(rut_colaborador=self.request.user.rut)
        incidencia = serializer.validated_data["id_incidencia"]

        # Validar permisos: Solo Logística, Administrador o el colaborador asignado pueden crear logs
        if not self.request.user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists():
            if (
                incidencia.rut_colaborador.rut_colaborador
                != colaborador.rut_colaborador
            ):
                raise ValidationError(
                    "No tienes permiso para añadir un log a esta incidencia."
                )

        # Guardar el log con el colaborador autenticado como el creador del comentario
        log = serializer.save(rut_colaborador=colaborador)

        # Si el usuario pertenece al grupo Logística, actualizar `fecha_ultima_modificacion` y `id_estado` de la incidencia
        if self.request.user.groups.filter(name="Logística").exists():
            # Definir la zona horaria de Santiago
            santiago_tz = pytz.timezone("America/Santiago")
            # Asignar la fecha y hora actual en la zona horaria de Santiago
            incidencia.fecha_ultima_modificacion = make_aware(
                datetime.now(), timezone=santiago_tz
            )
            incidencia.id_estado = (
                log.id_estado
            )  # Actualizar el estado de la incidencia
            incidencia.save(update_fields=["fecha_ultima_modificacion", "id_estado"])
