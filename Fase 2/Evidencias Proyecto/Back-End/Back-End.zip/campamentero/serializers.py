from rest_framework import serializers
from .models import (
    Ubicacion,
    Habitacion,
    AsignacionHabitacion,
    ComentarioCalidadHabitacion,
    LogEscaneoQRHabitacion,
    IncidenciaHabitacion,
    LogIncidenciaHabitacion,
)
from colaboradores.models import Colaborador
from django.utils import timezone
from datetime import time
import re
from unidecode import unidecode
from django.core.exceptions import ValidationError
from viajes.models import Estado
from django.contrib.auth.models import Group


# Serializer para Ubicacion
class UbicacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ubicacion
        fields = ["id", "nombre"]

    def validate(self, data):
        try:
            # Llamamos a clean() en el modelo para realizar la validación
            Ubicacion(**data).clean()
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)
        return data


# Serializer para Habitacion
class HabitacionSerializer(serializers.ModelSerializer):
    estado_nombre = serializers.CharField(source="estado.nombre_estado", read_only=True)
    ubicacion_nombre = serializers.CharField(source="ubicacion.nombre")

    class Meta:
        model = Habitacion
        fields = [
            "id",
            "nro_habitacion",
            "ubicacion",
            "ubicacion_nombre",
            "estado",
            "estado_nombre",
        ]

    def validate_nro_habitacion(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "El número de habitación debe ser mayor que 0."
            )
        return value

    def validate(self, attrs):
        nro_habitacion = attrs.get("nro_habitacion")
        ubicacion = attrs.get("ubicacion")

        # Validar que el número de habitación no exista en la misma ubicación
        if Habitacion.objects.filter(
            nro_habitacion=nro_habitacion, ubicacion=ubicacion
        ).exists():
            raise serializers.ValidationError(
                "Ya existe una habitación con este número en la ubicación seleccionada."
            )

        return attrs


# Serializer para AsignacionHabitacion
class AsignacionHabitacionSerializer(serializers.ModelSerializer):
    ubicacion = serializers.CharField(
        source="id_habitacion.ubicacion.nombre", read_only=True
    )
    estado_reserva_nombre = serializers.CharField(
        source="estado_reserva.nombre_estado", read_only=True
    )

    class Meta:
        model = AsignacionHabitacion
        fields = [
            "id",
            "rut_colaborador",
            "id_habitacion",
            "estado_reserva",  # Muestra el ID del estado
            "estado_reserva_nombre",  # Muestra el nombre del estado
            "hora_ingreso",
            "hora_salida",
            "fecha_ingreso",
            "fecha_salida",
            "fecha_real_ingreso",
            "fecha_real_salida",
            "hora_real_ingreso",
            "hora_real_salida",
            "ubicacion",
        ]

    def validate(self, attrs):
        habitacion = attrs.get("id_habitacion")
        fecha_ingreso = attrs.get("fecha_ingreso")
        fecha_salida = attrs.get("fecha_salida")
        rut_colaborador = attrs.get("rut_colaborador")
        ubicacion_requerida = attrs.get("ubicacion")

        # Validar que la fecha de ingreso y salida no sean pasadas
        if fecha_ingreso and fecha_ingreso < timezone.now().date():
            raise serializers.ValidationError(
                "La fecha de ingreso no puede ser anterior a la fecha actual."
            )
        if fecha_salida and fecha_salida < timezone.now().date():
            raise serializers.ValidationError(
                "La fecha de salida no puede ser anterior a la fecha actual."
            )

        # Validar que la fecha de salida sea posterior a la fecha de ingreso
        if fecha_ingreso and fecha_salida and fecha_salida <= fecha_ingreso:
            raise serializers.ValidationError(
                "La fecha de salida debe ser posterior a la fecha de ingreso."
            )

        # Validar que la habitación esté disponible en las fechas, excluyendo las asignaciones canceladas
        if habitacion and fecha_ingreso and fecha_salida:
            asignaciones_conflictivas = AsignacionHabitacion.objects.filter(
                id_habitacion=habitacion,
                fecha_ingreso__lte=fecha_salida,
                fecha_salida__gte=fecha_ingreso,
            ).exclude(
                estado_reserva_id=71
            )  # Excluir asignaciones canceladas

            if asignaciones_conflictivas.exists():
                raise serializers.ValidationError(
                    "La habitación no está disponible en las fechas solicitadas."
                )

        # Validar que el colaborador no esté asignado en otro lugar en el mismo período, excluyendo asignaciones canceladas
        if rut_colaborador and fecha_ingreso and fecha_salida:
            asignaciones_colaborador = AsignacionHabitacion.objects.filter(
                rut_colaborador=rut_colaborador,
                fecha_ingreso__lte=fecha_salida,
                fecha_salida__gte=fecha_ingreso,
            ).exclude(
                estado_reserva_id=71
            )  # Excluir asignaciones canceladas

            if asignaciones_colaborador.exists():
                raise serializers.ValidationError(
                    "El colaborador ya tiene una asignación en este período."
                )

        # Validar que la habitación pertenezca a la ubicación especificada
        if ubicacion_requerida and habitacion.ubicacion.nombre != ubicacion_requerida:
            raise serializers.ValidationError(
                "La habitación no corresponde a la ubicación especificada."
            )

        return attrs

    def validate_hora_ingreso(self, value):
        if value < time(0, 0) or value > time(23, 59):
            raise serializers.ValidationError(
                "La hora de ingreso debe estar entre 00:00 y 23:59."
            )
        return value

    def validate_hora_salida(self, value):
        if value < time(0, 0) or value > time(23, 59):
            raise serializers.ValidationError(
                "La hora de salida debe estar entre 00:00 y 23:59."
            )
        return value


# Serializer para ComentarioCalidadHabitacion
class ComentarioCalidadHabitacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComentarioCalidadHabitacion
        fields = ["id", "calidad", "comentario", "colaborador", "asignacion_habitacion"]

    def validate(self, attrs):
        colaborador = attrs.get("colaborador")
        asignacion_habitacion = attrs.get("asignacion_habitacion")
        comentario = attrs.get("comentario")

        # Verificar que la fecha real de salida esté establecida
        if not asignacion_habitacion.fecha_real_salida:
            raise serializers.ValidationError(
                "No se puede comentar hasta que el colaborador haya salido de la habitación."
            )

        # Validar comentario vacío
        if comentario is None or comentario.strip() == "":
            raise serializers.ValidationError("El comentario no puede estar vacío.")

        # Obtener el RUT del colaborador
        colaborador_rut = colaborador.rut_colaborador

        # Verifica si el colaborador ya ha calificado esta asignación
        if ComentarioCalidadHabitacion.objects.filter(
            colaborador=colaborador,
            asignacion_habitacion=asignacion_habitacion,
        ).exists():
            raise serializers.ValidationError(
                "El colaborador ya ha calificado esta asignación."
            )

        # Validar que el colaborador que califica sea el mismo que el usuario
        if self.context["request"].user.rut != colaborador_rut:
            raise serializers.ValidationError(
                "Acceso denegado. Solo el colaborador asignado puede calificar."
            )

        return attrs

    def validate_calidad(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("La calidad debe estar entre 1 y 5.")
        return value


# Serializer para LogEscaneoQRHabitacion
class LogEscaneoQRHabitacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = LogEscaneoQRHabitacion
        fields = [
            "id",
            "encargado",
            "colaborador",
            "asignacion_habitacion",
            "resultado",
            "ip_address",
            "ciudad",
            "pais",
            "tipo",
        ]

    def validate_resultado(self, value):
        valid_results = ["confirmado", "no_asignado", "qr_caducado", "no_coincide"]
        if value not in valid_results:
            raise serializers.ValidationError(
                "El resultado debe ser uno de los siguientes: 'confirmado', 'no_asignado', 'qr_caducado', 'no_coincide'."
            )
        return value

    def validate(self, attrs):
        if attrs.get("tipo") not in ["entrada", "salida"]:
            raise serializers.ValidationError("El tipo debe ser 'entrada' o 'salida'.")
        return attrs


# Serializer para Generar QR
class GenerarQRHabitacionSerializer(serializers.Serializer):
    qr_code = serializers.CharField(max_length=255)  # Especifica un max_length adecuado
    qr_token = serializers.CharField(
        max_length=255
    )  # Especifica un max_length adecuado
    qr_timestamp = serializers.IntegerField()

    class Meta:
        fields = ["qr_code", "qr_token", "qr_timestamp"]

    def validate_qr_timestamp(self, value):
        if value < 0:
            raise serializers.ValidationError("El timestamp del QR no es válido.")
        return value


# Serializer para Validar QR
class ValidarQRHabitacionSerializer(serializers.Serializer):
    rut_colaborador = serializers.CharField(max_length=12)
    id_asignacion = serializers.IntegerField()
    qr_token = serializers.CharField(
        max_length=255
    )  # Especifica un max_length adecuado
    qr_timestamp = serializers.IntegerField()

    class Meta:
        fields = ["rut_colaborador", "id_asignacion", "qr_token", "qr_timestamp"]

    def validate_qr_timestamp(self, value):
        if value < 0:
            raise serializers.ValidationError("El timestamp del QR no es válido.")
        return value

    def validate_id_asignacion(self, value):
        # Verificar que la asignación exista
        if not AsignacionHabitacion.objects.filter(id=value).exists():
            raise serializers.ValidationError("La asignación de habitación no existe.")
        return value


class InfoAsignacionSerializer(serializers.ModelSerializer):
    habitacion = serializers.SerializerMethodField()
    colaborador = serializers.SerializerMethodField()
    estado_reserva = serializers.SerializerMethodField()
    incidencia_activa = serializers.SerializerMethodField()
    incidencia = serializers.SerializerMethodField()

    class Meta:
        model = AsignacionHabitacion
        fields = [
            "id",
            "habitacion",
            "colaborador",
            "estado_reserva",
            "fecha_ingreso",
            "fecha_salida",
            "hora_ingreso",
            "hora_salida",
            "fecha_real_ingreso",
            "fecha_real_salida",
            "hora_real_ingreso",
            "hora_real_salida",
            "incidencia_activa",
            "incidencia",
        ]

    def get_habitacion(self, obj):
        return {
            "nro_habitacion": obj.id_habitacion.nro_habitacion,
            "ubicacion": {
                "id": obj.id_habitacion.ubicacion.id,
                "nombre": obj.id_habitacion.ubicacion.nombre,
            },
            "estado": {
                "id": obj.id_habitacion.estado.id,
                "nombre": obj.id_habitacion.estado.nombre_estado,
            },
        }

    def get_colaborador(self, obj):
        colaborador = obj.rut_colaborador
        contrato_activo = colaborador.contratos.filter(estado="Activo").first()

        return {
            "rut_colaborador": colaborador.rut_colaborador,
            "nombre": f"{colaborador.nombres} {colaborador.apellido_paterno} {colaborador.apellido_materno}",
            "email": colaborador.email,
            "turno": contrato_activo.turno if contrato_activo else "Sin turno asignado",
        }

    def get_estado_reserva(self, obj):
        return {"id": obj.estado_reserva.id, "nombre": obj.estado_reserva.nombre_estado}

    def get_incidencia_activa(self, obj):
        estados_activos = [100, 101, 102, 103]
        incidencia_activa = obj.incidencias.filter(
            id_estado__id__in=estados_activos
        ).exists()
        return incidencia_activa

    def get_incidencia(self, obj):
        # Obtener la incidencia activa si existe y devolver los detalles
        incidencia = obj.incidencias.filter(
            id_estado__id__in=[100, 101, 102, 103]
        ).first()

        if incidencia:
            return {
                "id": incidencia.id,
                "estado": incidencia.id_estado.id,
                "nombre_estado": incidencia.id_estado.nombre_estado,  # Agregado el nombre del estado
            }
        return None  # No hay incidencia activa


class IncidenciaHabitacionSerializer(serializers.ModelSerializer):
    estado_nombre = serializers.CharField(
        source="id_estado.nombre_estado", read_only=True
    )
    fecha_creacion = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    fecha_ultima_modificacion = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    nombres = serializers.CharField(source="rut_colaborador.nombres", read_only=True)
    apellido_paterno = serializers.CharField(
        source="rut_colaborador.apellido_paterno", read_only=True
    )
    apellido_materno = serializers.CharField(
        source="rut_colaborador.apellido_materno", read_only=True
    )

    class Meta:
        model = IncidenciaHabitacion
        fields = [
            "id",
            "rut_colaborador",
            "nombres",
            "apellido_paterno",
            "apellido_materno",
            "id_asignacion_habitacion",
            "fecha_creacion",
            "fecha_ultima_modificacion",
            "id_estado",
            "estado_nombre",
            "comentario",
        ]

    def get_nombre_completo_colaborador(self, obj):
        # Concatenar nombres y apellidos del colaborador
        return f"{obj.rut_colaborador.nombres} {obj.rut_colaborador.apellido_paterno} {obj.rut_colaborador.apellido_materno}"

    def validate(self, attrs):
        rut_colaborador = attrs.get("rut_colaborador")
        asignacion_habitacion = attrs.get("id_asignacion_habitacion")
        comentario = attrs.get("comentario")
        current_date = timezone.now().date()
        request_user = self.context["request"].user
        es_logistica_o_admin = request_user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists()
        id_estado = attrs.get("id_estado")

        # Si es PATCH, omitir la validación de campos obligatorios
        if self.context["request"].method != "PATCH":
            if rut_colaborador is None:
                raise serializers.ValidationError(
                    "El campo rut_colaborador es obligatorio."
                )
            if asignacion_habitacion is None:
                raise serializers.ValidationError(
                    "El campo id_asignacion_habitacion es obligatorio."
                )
            if comentario is None or comentario.strip() == "":
                raise serializers.ValidationError("El comentario no puede estar vacío.")

        # Permitir acceso solo si el usuario es el colaborador asignado o Logística/Admin
        if rut_colaborador and not (
            request_user.rut == rut_colaborador.rut_colaborador or es_logistica_o_admin
        ):
            raise serializers.ValidationError(
                "Acceso denegado. Solo el colaborador asignado o el equipo de Logística/Administrador pueden gestionar la incidencia."
            )

        # Validar permisos de cambio de estado
        if id_estado:
            if id_estado.id in [101, 102, 103, 104] and not es_logistica_o_admin:
                raise serializers.ValidationError(
                    "Solo el equipo de Logística/Administrador puede asignar los estados 101, 102, 103 y 104."
                )
            if id_estado.id in [100, 105] and es_logistica_o_admin:
                raise serializers.ValidationError(
                    "Solo el colaborador asignado puede asignar los estados 100 y 105."
                )

        # Validar que la incidencia solo pueda reportarse entre la fecha de ingreso y salida
        if asignacion_habitacion and not (
            asignacion_habitacion.fecha_ingreso
            <= current_date
            <= asignacion_habitacion.fecha_salida
        ):
            raise serializers.ValidationError(
                "La incidencia solo puede reportarse entre la fecha de ingreso y la fecha de salida."
            )

        return attrs

    def update(self, instance, validated_data):
        # Validar que no se pueda actualizar si el estado actual es 105 (Cerrada)
        if instance.id_estado.id == 105:
            raise serializers.ValidationError(
                "No se pueden realizar cambios en una incidencia que ha sido cerrada."
            )

        request = self.context.get("request")
        previous_estado = instance.id_estado

        # Actualizar la incidencia y la fecha de última modificación
        instance = super().update(instance, validated_data)
        instance.fecha_ultima_modificacion = timezone.now()
        instance.save(update_fields=["fecha_ultima_modificacion"])

        # Crear log con mensaje automático si el estado cambia a 101
        if (
            request.user.groups.filter(name__in=["Logística", "Administrador"]).exists()
            and instance.id_estado.id == 101
            and previous_estado != instance.id_estado
        ):
            colaborador = Colaborador.objects.get(rut_colaborador=request.user.rut)
            LogIncidenciaHabitacion.objects.create(
                id_incidencia=instance,
                rut_colaborador=colaborador,
                comentario="Incidencia en Revisión, pronto lo contactaremos",
                id_estado=instance.id_estado,
            )

        return instance

    def create(self, validated_data):
        # Asignar el estado "Reportada" automáticamente al crear la incidencia
        estado_reportada, created = Estado.objects.get_or_create(
            nombre_estado="Reportada", entidad="Incidencia"
        )
        validated_data["id_estado"] = estado_reportada
        return super().create(validated_data)


class LogIncidenciaHabitacionSerializer(serializers.ModelSerializer):
    rut_colaborador = serializers.SlugRelatedField(
        slug_field="rut_colaborador",
        queryset=Colaborador.objects.all(),
    )
    estado_nombre = serializers.CharField(
        source="id_estado.nombre_estado", read_only=True
    )
    fecha_comentario = serializers.DateTimeField(
        format="%Y-%m-%dT%H:%M:%S", read_only=True
    )
    nombres = serializers.CharField(source="rut_colaborador.nombres", read_only=True)
    apellido_paterno = serializers.CharField(
        source="rut_colaborador.apellido_paterno", read_only=True
    )
    apellido_materno = serializers.CharField(
        source="rut_colaborador.apellido_materno", read_only=True
    )

    class Meta:
        model = LogIncidenciaHabitacion
        fields = [
            "id",
            "fecha_comentario",
            "comentario",
            "rut_colaborador",
            "estado_nombre",
            "nombres",
            "apellido_paterno",
            "apellido_materno",
            "id_incidencia",
            "id_estado",
        ]

    def get_nombre_completo_colaborador(self, obj):
        # Concatenar nombres y apellidos del colaborador
        return f"{obj.rut_colaborador.nombres} {obj.rut_colaborador.apellido_paterno} {obj.rut_colaborador.apellido_materno}"

    def validate(self, data):
        request = self.context.get("request")
        incidencia = data["id_incidencia"]
        es_logistica_o_admin = request.user.groups.filter(
            name__in=["Logística", "Administrador"]
        ).exists()

        # Verificar que la incidencia no esté cerrada
        if incidencia.id_estado.id == 105:
            raise serializers.ValidationError(
                "No se pueden realizar más cambios en una incidencia que ha sido cerrada."
            )

        # Verificar que el colaborador asignado o Logística/Admin pueden gestionar el log
        if (
            not es_logistica_o_admin
            and incidencia.rut_colaborador.rut_colaborador != request.user.rut
        ):
            raise serializers.ValidationError(
                "Acceso denegado. Solo el colaborador asignado o el equipo de Logística/Administrador pueden gestionar la incidencia."
            )

        # Restricciones para el colaborador asignado
        if not es_logistica_o_admin:
            # Si el colaborador intenta cambiar el estado, solo se permite "Cerrada" (105)
            estado_id = data.get("id_estado", None)
            if estado_id is not None and estado_id.id != 105:
                raise serializers.ValidationError(
                    "No tienes permiso para cambiar el estado a algo distinto de 'Cerrada'."
                )
            # No permitir que el colaborador cambie el estado si no está cerrando
            if estado_id is None:
                data["id_estado"] = incidencia.id_estado  # Mantener el estado actual

        # Restricción para Logística/Admin: No pueden asignar el estado "Reportada" o "Cerrada"
        if (
            es_logistica_o_admin
            and data.get("id_estado", None)
            and data["id_estado"].id in [100, 105]
        ):
            raise serializers.ValidationError(
                "El equipo de Logística o Administrador no puede asignar el estado 'Reportada' o 'Cerrada'."
            )

        return data

    def create(self, validated_data):
        # Crear un nuevo registro en LogIncidenciaHabitacion
        log = LogIncidenciaHabitacion.objects.create(**validated_data)

        # Solo actualizar la fecha de última modificación en la incidencia principal
        incidencia = validated_data["id_incidencia"]
        incidencia.fecha_ultima_modificacion = timezone.now()
        incidencia.save(update_fields=["fecha_ultima_modificacion"])

        return log
