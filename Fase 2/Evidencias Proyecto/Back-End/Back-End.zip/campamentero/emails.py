from django.core.mail import EmailMultiAlternatives
from django.conf import settings
from email.mime.image import MIMEImage
import os
from babel.dates import format_date


def enviar_correo_asignacion(asignacion):
    colaborador = asignacion.rut_colaborador
    habitacion = asignacion.id_habitacion

    # Tomar el primer nombre y apellidos
    primer_nombre = colaborador.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = colaborador.apellido_paterno
    apellido_materno = colaborador.apellido_materno

    subject = "Asignación de Habitación"
    text_content = f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, se le ha asignado una habitación."

    # Ruta local de la imagen
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Formatear las fechas al estilo "Jueves 21 de noviembre del 2024"
    fecha_ingreso_formateada = format_date(
        asignacion.fecha_ingreso, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )
    fecha_salida_formateada = format_date(
        asignacion.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #28a745;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Asignación de Habitación</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Se le ha asignado una habitación con los siguientes detalles:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Habitación:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{habitacion.nro_habitacion}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Ubicación:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{habitacion.ubicacion.nombre}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Estado de Reserva:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{asignacion.estado_reserva.nombre_estado}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Ingreso:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_ingreso_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Ingreso:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{asignacion.hora_ingreso}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Hora de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{asignacion.hora_salida}</td>
                    </tr>
                </table>
                <p style="margin-top: 20px; text-align: center;">Por favor, asegúrese de presentarse en la fecha y hora indicada.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear el mensaje
    msg = EmailMultiAlternatives(
        subject, text_content, settings.EMAIL_HOST_USER, [colaborador.email]
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen como contenido embebido usando MIMEImage
    with open(logo_path, "rb") as f:
        msg_image = MIMEImage(f.read())
        msg_image.add_header("Content-ID", "<logo_image>")
        msg.attach(msg_image)

    # Enviar el correo
    msg.send()


def enviar_correo_cancelacion(asignacion):
    colaborador = asignacion.rut_colaborador
    habitacion = asignacion.id_habitacion

    # Tomar el primer nombre y apellidos
    primer_nombre = colaborador.nombres.split(" ")[0]  # Tomar solo el primer nombre
    apellido_paterno = colaborador.apellido_paterno
    apellido_materno = colaborador.apellido_materno

    subject = "Cancelación de Reserva de Habitación"
    text_content = f"Estimado/a {primer_nombre} {apellido_paterno} {apellido_materno}, su reserva ha sido cancelada."

    # Ruta local de la imagen
    logo_path = os.path.join(settings.BASE_DIR, "staticfiles/images/logo.png")

    # Formatear las fechas al estilo "Jueves 21 de noviembre del 2024"
    fecha_ingreso_formateada = format_date(
        asignacion.fecha_ingreso, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )
    fecha_salida_formateada = format_date(
        asignacion.fecha_salida, "EEEE d 'de' MMMM 'del' y", locale="es_ES"
    )

    html_content = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0;">
        <div style="width: 100%; background-color: #f4f4f4; padding: 20px 0;">
            <div style="max-width: 600px; background-color: #ffffff; margin: auto; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border-top: 8px solid #dc3545;">
                
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="cid:logo_image" alt="VeteranBytes Logo" style="width: 60px; height: auto; margin-right: 15px;">
                    <h2 style="color: #2C3E50; margin: 0;">Cancelación de Reserva</h2>
                </div>

                <p>Estimado/a <strong>{primer_nombre} {apellido_paterno} {apellido_materno}</strong>,</p>
                <p>Lamentamos informarle que su reserva para la habitación ha sido cancelada:</p>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Habitación:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{habitacion.nro_habitacion}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Ubicación:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{habitacion.ubicacion.nombre}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Estado de Reserva:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{asignacion.estado_reserva.nombre_estado}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Ingreso:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_ingreso_formateada}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Fecha de Salida:</strong></td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">{fecha_salida_formateada}</td>
                    </tr>
                </table>
                <p style="margin-top: 20px; text-align: center;">Si tiene alguna pregunta, por favor contacte a nuestro equipo.</p>
                <p style="text-align: center;">Saludos,<br>VeteranBytes</p>
            </div>
        </div>
    </body>
    </html>
    """

    # Crear el mensaje
    msg = EmailMultiAlternatives(
        subject, text_content, settings.EMAIL_HOST_USER, [colaborador.email]
    )
    msg.attach_alternative(html_content, "text/html")

    # Adjuntar la imagen como contenido embebido usando MIMEImage
    with open(logo_path, "rb") as f:
        msg_image = MIMEImage(f.read())
        msg_image.add_header("Content-ID", "<logo_image>")
        msg.attach(msg_image)

    # Enviar el correo
    msg.send()
