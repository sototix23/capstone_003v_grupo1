import qrcode
from io import BytesIO
import base64
import hashlib
import time


def generar_codigo_qr(colaborador, asignacion, tipo):
    """
    Genera un código QR dinámico para la entrada o salida.
    tipo: 'entrada' o 'salida'
    """
    # Crear el token basado en el colaborador, asignación de habitación y tipo
    qr_token = hashlib.sha256(
        f"{colaborador.rut_colaborador}-{asignacion.id}-{tipo}".encode()
    ).hexdigest()

    # Obtener el timestamp actual
    qr_timestamp = int(time.time())

    # Crear la URL o cadena con el token del QR y otra información relevante
    data = f"Tipo: {tipo}, Token: {qr_token}, Timestamp: {qr_timestamp}"

    # Generar el código QR
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)

    # Convertir a imagen
    img = qr.make_image(fill="black", back_color="white")

    # Guardar la imagen en un buffer
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    qr_image_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")

    return {
        "qr_code": qr_image_base64,  # Código QR en base64
        "qr_token": qr_token,  # Token hash para comparación
        "qr_timestamp": qr_timestamp,  # Timestamp del QR
    }
