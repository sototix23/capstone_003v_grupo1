from django.db import models
from rest_framework import serializers
from .validators import validar_fecha_ingreso, validar_fecha_salida
from colaboradores.models import Colaborador
from django.core.exceptions import ValidationError
from viajes.models import Estado
import re
from unidecode import unidecode
from django.utils import timezone


# Modelo Ubicacion
class Ubicacion(models.Model):
    nombre = models.CharField(max_length=255, unique=True)

    class Meta:
        ordering = ["nombre"]

    def clean(self):
        # Normalizar el nombre eliminando acentos y convirtiéndolo en minúsculas
        normalized_name = unidecode(self.nombre).lower()

        # Verificar el formato específico: número seguido de palabra, opcionalmente seguido de una letra
        if not re.match(r"^\d+\s[A-Za-z]+(\s[A-Za-z])?$", self.nombre):
            raise ValidationError(
                "El nombre debe seguir el formato 'Numero Espacio Palabra' o 'Numero Espacio Palabra Espacio Letra' (ej: '27 Norte' o '27 Norte C')."
            )

        # Verificar duplicados ignorando espacios
        if (
            Ubicacion.objects.filter(nombre__iexact=normalized_name.replace(" ", ""))
            .exclude(pk=self.pk)
            .exists()
        ):
            raise ValidationError("Ya existe una ubicación similar.")

        # Aplicar formato consistente (e.g., título)
        self.nombre = self.nombre.title()

    def save(self, *args, **kwargs):
        # Asegura que siempre se aplique la validación antes de guardar
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nombre


# Modelo Habitacion
class Habitacion(models.Model):
    nro_habitacion = models.PositiveIntegerField()
    ubicacion = models.ForeignKey(Ubicacion, on_delete=models.CASCADE)
    estado = models.ForeignKey(
        Estado,
        on_delete=models.PROTECT,
        limit_choices_to={"entidad": "Habitacion"},
        default=67,
    )

    def esta_disponible(self, fecha_ingreso, fecha_salida):
        return not AsignacionHabitacion.objects.filter(
            id_habitacion=self,
            fecha_ingreso__lte=fecha_salida,
            fecha_salida__gte=fecha_ingreso,
        ).exists()

    class Meta:
        unique_together = ("nro_habitacion", "ubicacion")

    def __str__(self):
        return f"Habitación {self.nro_habitacion} - {self.ubicacion.nombre}"


# Modelo de AsignacionHabitacion
class AsignacionHabitacion(models.Model):
    rut_colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="asignaciones_habitacion"
    )
    id_habitacion = models.ForeignKey(
        Habitacion, on_delete=models.CASCADE, related_name="asignaciones"
    )
    estado_reserva = models.ForeignKey(
        Estado,
        on_delete=models.PROTECT,
        limit_choices_to={"entidad": "Reserva"},
        default=69,
    )
    hora_ingreso = models.TimeField()
    hora_salida = models.TimeField()
    fecha_ingreso = models.DateField()
    fecha_salida = models.DateField()
    fecha_real_ingreso = models.DateField(null=True, blank=True)
    fecha_real_salida = models.DateField(null=True, blank=True)
    hora_real_ingreso = models.DateTimeField(null=True, blank=True)
    hora_real_salida = models.DateTimeField(null=True, blank=True)

    def clean(self):
        super().clean()
        ocupaciones = AsignacionHabitacion.objects.filter(
            id_habitacion=self.id_habitacion,
            fecha_ingreso__lte=self.fecha_salida,
            fecha_salida__gte=self.fecha_ingreso,
        )
        if ocupaciones.exists():
            raise ValidationError(
                "La habitación no está disponible en las fechas solicitadas."
            )

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        super().delete(*args, **kwargs)

    def __str__(self):
        return f"Asignación de {self.rut_colaborador} a {self.id_habitacion}"


class ComentarioCalidadHabitacion(models.Model):
    calidad = models.IntegerField(
        choices=[(i, str(i)) for i in range(1, 6)], default=1  # Valores de 1 a 5
    )
    comentario = models.TextField(null=True, blank=True)  # Comentario opcional
    colaborador = models.ForeignKey(Colaborador, on_delete=models.CASCADE)
    asignacion_habitacion = models.ForeignKey(
        AsignacionHabitacion, on_delete=models.CASCADE
    )
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = (
            "colaborador",
            "asignacion_habitacion",
        )  # Un colaborador puede calificar solo una vez por asignación

    def __str__(self):
        return f"Calidad de {self.calidad} para asignación {self.asignacion_habitacion}"


class LogEscaneoQRHabitacion(models.Model):
    encargado = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="escaneos_realizados"
    )
    colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="escaneos_recibidos"
    )
    asignacion_habitacion = models.ForeignKey(
        AsignacionHabitacion, on_delete=models.CASCADE
    )
    fecha_hora_escaneo = models.DateTimeField(auto_now_add=True)
    resultado = models.CharField(
        max_length=50,
        choices=[
            ("confirmado", "Asistencia confirmada"),
            ("no_asignado", "Colaborador no asignado"),
            ("qr_caducado", "QR caducado"),
            ("no_coincide", "Datos no coinciden"),
        ],
        default="no_coincide",
    )
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    ciudad = models.CharField(max_length=100, null=True, blank=True)
    pais = models.CharField(max_length=100, null=True, blank=True)
    tipo = models.CharField(
        max_length=10,
        choices=[("entrada", "Entrada"), ("salida", "Salida")],
        default="entrada",
    )
    latitud = models.FloatField(null=True, blank=True)
    longitud = models.FloatField(null=True, blank=True)

    def __str__(self):
        return (
            f"Escaneo por {self.encargado} de {self.colaborador} "
            f"para asignación {self.asignacion_habitacion} el {self.fecha_hora_escaneo}"
        )


class IncidenciaHabitacion(models.Model):
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_ultima_modificacion = models.DateTimeField(
        null=True, blank=True
    )  # Cambiado para permitir null
    rut_colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="incidencias_reportadas"
    )
    comentario = models.TextField()
    id_estado = models.ForeignKey(
        Estado,
        on_delete=models.SET_NULL,
        null=True,
        limit_choices_to={"entidad": "Incidencia"},
        related_name="incidencias",
    )
    id_asignacion_habitacion = models.ForeignKey(
        AsignacionHabitacion, on_delete=models.CASCADE, related_name="incidencias"
    )

    class Meta:
        # Elimina la restricción de unicidad
        # unique_together = ("rut_colaborador", "id_asignacion_habitacion")
        pass

    def __str__(self):
        return f"Incidencia en {self.id_asignacion_habitacion} - {self.id_estado.nombre_estado if self.id_estado else 'Estado no asignado'}"


class LogIncidenciaHabitacion(models.Model):
    fecha_comentario = models.DateTimeField(auto_now_add=True)
    comentario = models.TextField()
    rut_colaborador = models.ForeignKey(
        Colaborador, on_delete=models.CASCADE, related_name="log_comentarios"
    )
    id_estado = models.ForeignKey(
        Estado,
        on_delete=models.SET_NULL,
        null=True,
        limit_choices_to={"entidad": "Incidencia"},
        related_name="log_incidencias",
    )
    id_incidencia = models.ForeignKey(
        IncidenciaHabitacion, on_delete=models.CASCADE, related_name="log_incidencias"
    )

    def save(self, *args, **kwargs):
        # Actualizar el estado y la fecha de última modificación en IncidenciaHabitacion
        self.id_incidencia.id_estado = (
            self.id_estado
        )  # Actualizar el estado de la incidencia
        self.id_incidencia.fecha_ultima_modificacion = timezone.now()
        self.id_incidencia.save()  # Guarda la incidencia con los cambios de estado y fecha

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Log de Incidencia {self.id} para Incidencia {self.id_incidencia.id}"
