from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Colaborador, Direccion, Contrato
from .serializers import ColaboradorSerializer, DireccionSerializer, ContratoSerializer
from .permissions import IsAdminOrLogistica
from rest_framework.views import APIView
from rest_framework.response import Response


class ColaboradorViewSet(viewsets.ModelViewSet):
    queryset = Colaborador.objects.all()
    serializer_class = ColaboradorSerializer
    permission_classes = [IsAuthenticated, IsAdminOrLogistica]
    lookup_field = "rut_colaborador"  # Usamos rut_colaborador en lugar de id


class DireccionViewSet(viewsets.ModelViewSet):
    serializer_class = DireccionSerializer
    permission_classes = [IsAuthenticated, IsAdminOrLogistica]

    def get_queryset(self):
        """
        Filtramos las direcciones basadas en el rut del colaborador.
        """
        rut_colaborador = self.kwargs.get("rut_colaborador")
        if rut_colaborador:
            return Direccion.objects.filter(
                colaborador__rut_colaborador=rut_colaborador
            )
        return (
            Direccion.objects.all()
        )  # Retorna todas las direcciones si no se pasa rut_colaborador

    lookup_field = (
        "id"  # Usamos el ID de la dirección para recuperar, actualizar o eliminar
    )


class ContratoViewSet(viewsets.ModelViewSet):
    serializer_class = ContratoSerializer
    permission_classes = [IsAuthenticated, IsAdminOrLogistica]

    def get_queryset(self):
        """
        Filtramos los contratos basados en el rut del colaborador.
        """
        rut_colaborador = self.kwargs.get("rut_colaborador")
        if rut_colaborador:
            return Contrato.objects.filter(colaborador__rut_colaborador=rut_colaborador)
        return (
            Contrato.objects.all()
        )  # Retorna todos los contratos si no se pasa rut_colaborador

    lookup_field = (
        "id"  # Usamos el ID del contrato para recuperar, actualizar o eliminar
    )


class RegionesComunasView(APIView):
    """
    Vista para obtener las regiones con sus respectivas comunas agrupadas.
    """

    def get(self, request):
        # Diccionario para agrupar las comunas por región
        regiones_comunas = {}

        # Consultar todas las combinaciones únicas de región y comuna
        direcciones = Direccion.objects.values("region", "comuna").distinct()

        for direccion in direcciones:
            region = direccion["region"]
            comuna = direccion["comuna"]

            # Si la región no está en el diccionario, la añadimos
            if region not in regiones_comunas:
                regiones_comunas[region] = []

            # Añadir la comuna a la región si no está ya añadida
            if comuna not in regiones_comunas[region]:
                regiones_comunas[region].append(comuna)

        # Preparar la respuesta en el formato adecuado
        data = [
            {"region": region, "comunas": comunas}
            for region, comunas in regiones_comunas.items()
        ]

        return Response(data)
