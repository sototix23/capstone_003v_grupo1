from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ColaboradorViewSet,
    DireccionViewSet,
    ContratoViewSet,
    RegionesComunasView,
)

# Mantén el DefaultRouter solo para las rutas de colaboradores
router = DefaultRouter()
router.register(r"", ColaboradorViewSet, basename="colaboradores")

urlpatterns = [
    # 1. Define la ruta de "regiones-comunas" primero para que no sea interceptada por el router
    path(
        "regiones-comunas/",  # Ruta simplificada para obtener regiones y comunas
        RegionesComunasView.as_view(),
        name="regiones-comunas",
    ),
    # 2. Luego incluyes las rutas del router
    path("", include(router.urls)),
    # Rutas de direcciones
    path(
        "<rut_colaborador>/direcciones/",
        DireccionViewSet.as_view(
            {
                "get": "list",
                "post": "create",
            }
        ),
        name="colaborador-direcciones-list-create",
    ),
    path(
        "<rut_colaborador>/direcciones/<int:id>/",
        DireccionViewSet.as_view(
            {
                "get": "retrieve",
                "put": "update",
                "patch": "partial_update",
                "delete": "destroy",
            }
        ),
        name="colaborador-direccion-detail",
    ),
    # Rutas de contratos
    path(
        "<rut_colaborador>/contratos/",
        ContratoViewSet.as_view(
            {
                "get": "list",
                "post": "create",
            }
        ),
        name="colaborador-contratos-list-create",
    ),
    path(
        "<rut_colaborador>/contratos/<int:id>/",
        ContratoViewSet.as_view(
            {
                "get": "retrieve",
                "put": "update",
                "patch": "partial_update",
                "delete": "destroy",
            }
        ),
        name="colaborador-contrato-detail",
    ),
]
